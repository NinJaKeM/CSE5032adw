package handlers

import (
	"net/http"

	"library-management-api/internal/models"
	"library-management-api/internal/response"
	"library-management-api/internal/services"
)

// LoanHandler — обработчики /api/loans и /api/statistics.
type LoanHandler struct {
	loans *services.LoanService
	stats *services.StatisticsService
}

// NewLoanHandler создаёт обработчики выдач и статистики.
func NewLoanHandler(loans *services.LoanService, stats *services.StatisticsService) *LoanHandler {
	return &LoanHandler{loans: loans, stats: stats}
}

// List — GET /api/loans.
func (h *LoanHandler) List(w http.ResponseWriter, r *http.Request) {
	response.Success(w, http.StatusOK, h.loans.List())
}

// Active — GET /api/loans/active.
func (h *LoanHandler) Active(w http.ResponseWriter, r *http.Request) {
	response.Success(w, http.StatusOK, h.loans.Active())
}

// Get — GET /api/loans/{id}.
func (h *LoanHandler) Get(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	loan, err := h.loans.Get(id)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, loan)
}

// Issue — POST /api/loans (выдать книгу).
func (h *LoanHandler) Issue(w http.ResponseWriter, r *http.Request) {
	var in models.LoanInput
	if err := decodeJSON(w, r, &in); err != nil {
		response.Error(w, err)
		return
	}
	loan, err := h.loans.Issue(in)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusCreated, loan)
}

// Return — PUT /api/loans/{id}/return (вернуть книгу).
func (h *LoanHandler) Return(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	loan, err := h.loans.Return(id)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, loan)
}

// Statistics — GET /api/statistics.
func (h *LoanHandler) Statistics(w http.ResponseWriter, r *http.Request) {
	response.Success(w, http.StatusOK, h.stats.Get())
}
