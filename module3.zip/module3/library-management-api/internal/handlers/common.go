// Package handlers содержит HTTP-обработчики: разбор запроса, вызов сервиса и отправку ответа.
package handlers

import (
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strconv"
	"strings"

	"library-management-api/internal/apperr"
)

const maxBodyBytes = 1 << 20 // 1 МБ

// decodeJSON читает тело запроса в dst. Пустое тело, синтаксическая ошибка, неверный тип поля,
// неизвестное поле или лишние данные после объекта — 400 INVALID_JSON.
func decodeJSON(w http.ResponseWriter, r *http.Request, dst any) error {
	r.Body = http.MaxBytesReader(w, r.Body, maxBodyBytes)
	dec := json.NewDecoder(r.Body)
	dec.DisallowUnknownFields()

	if err := dec.Decode(dst); err != nil {
		var syntaxErr *json.SyntaxError
		var typeErr *json.UnmarshalTypeError
		var maxErr *http.MaxBytesError
		switch {
		case errors.Is(err, io.EOF):
			return apperr.BadRequest(apperr.CodeInvalidJSON, "Тело запроса пустое")
		case errors.As(err, &syntaxErr), errors.Is(err, io.ErrUnexpectedEOF):
			return apperr.BadRequest(apperr.CodeInvalidJSON, "Некорректный JSON")
		case errors.As(err, &typeErr):
			return apperr.BadRequest(apperr.CodeInvalidJSON, "Поле "+typeErr.Field+" имеет неверный тип")
		case errors.As(err, &maxErr):
			return apperr.BadRequest(apperr.CodeInvalidJSON, "Тело запроса слишком большое")
		case strings.HasPrefix(err.Error(), "json: unknown field "):
			return apperr.BadRequest(apperr.CodeInvalidJSON, "Неизвестное поле "+strings.TrimPrefix(err.Error(), "json: unknown field "))
		default:
			return apperr.BadRequest(apperr.CodeInvalidJSON, "Некорректный JSON")
		}
	}
	if dec.More() {
		return apperr.BadRequest(apperr.CodeInvalidJSON, "После JSON-объекта есть лишние данные")
	}
	return nil
}

// pathID извлекает положительный целый path-параметр {id}.
func pathID(r *http.Request) (int, error) {
	id, err := strconv.Atoi(r.PathValue("id"))
	if err != nil || id <= 0 {
		return 0, apperr.BadRequest(apperr.CodeInvalidID, "Идентификатор должен быть положительным целым числом")
	}
	return id, nil
}
