package handlers

import (
	"net/http"

	"library-management-api/internal/models"
	"library-management-api/internal/response"
	"library-management-api/internal/services"
)

// ReaderHandler — обработчики /api/readers.
type ReaderHandler struct {
	readers *services.ReaderService
}

// NewReaderHandler создаёт обработчики читателей.
func NewReaderHandler(readers *services.ReaderService) *ReaderHandler {
	return &ReaderHandler{readers: readers}
}

// List — GET /api/readers (поиск по имени: ?name=).
func (h *ReaderHandler) List(w http.ResponseWriter, r *http.Request) {
	response.Success(w, http.StatusOK, h.readers.List(r.URL.Query().Get("name")))
}

// Get — GET /api/readers/{id}.
func (h *ReaderHandler) Get(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	reader, err := h.readers.Get(id)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, reader)
}

// Create — POST /api/readers.
func (h *ReaderHandler) Create(w http.ResponseWriter, r *http.Request) {
	var in models.ReaderInput
	if err := decodeJSON(w, r, &in); err != nil {
		response.Error(w, err)
		return
	}
	reader, err := h.readers.Create(in)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusCreated, reader)
}

// Update — PUT /api/readers/{id}.
func (h *ReaderHandler) Update(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	var in models.ReaderInput
	if err := decodeJSON(w, r, &in); err != nil {
		response.Error(w, err)
		return
	}
	reader, err := h.readers.Update(id, in)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, reader)
}

// Delete — DELETE /api/readers/{id}.
func (h *ReaderHandler) Delete(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	if err := h.readers.Delete(id); err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, map[string]any{"id": id, "deleted": true})
}

// Loans — GET /api/readers/{id}/loans (история выдач).
func (h *ReaderHandler) Loans(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	loans, err := h.readers.Loans(id)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, loans)
}
