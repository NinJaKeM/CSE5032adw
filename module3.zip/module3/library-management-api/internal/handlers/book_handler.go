package handlers

import (
	"net/http"

	"library-management-api/internal/models"
	"library-management-api/internal/response"
	"library-management-api/internal/services"
)

// BookHandler — обработчики /api/books.
type BookHandler struct {
	books *services.BookService
}

// NewBookHandler создаёт обработчики книг.
func NewBookHandler(books *services.BookService) *BookHandler {
	return &BookHandler{books: books}
}

// List — GET /api/books.
func (h *BookHandler) List(w http.ResponseWriter, r *http.Request) {
	response.Success(w, http.StatusOK, h.books.List())
}

// Get — GET /api/books/{id}.
func (h *BookHandler) Get(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	book, err := h.books.Get(id)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, book)
}

// Create — POST /api/books.
func (h *BookHandler) Create(w http.ResponseWriter, r *http.Request) {
	var in models.BookInput
	if err := decodeJSON(w, r, &in); err != nil {
		response.Error(w, err)
		return
	}
	book, err := h.books.Create(in)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusCreated, book)
}

// Update — PUT /api/books/{id}.
func (h *BookHandler) Update(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	var in models.BookInput
	if err := decodeJSON(w, r, &in); err != nil {
		response.Error(w, err)
		return
	}
	book, err := h.books.Update(id, in)
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, book)
}

// Delete — DELETE /api/books/{id}.
func (h *BookHandler) Delete(w http.ResponseWriter, r *http.Request) {
	id, err := pathID(r)
	if err != nil {
		response.Error(w, err)
		return
	}
	if err := h.books.Delete(id); err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, map[string]any{"id": id, "deleted": true})
}

// Search — GET /api/books/search?title=&author=&genre=&year=.
func (h *BookHandler) Search(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	filter, err := services.ParseBookFilter(q.Get("title"), q.Get("author"), q.Get("genre"), q.Get("year"))
	if err != nil {
		response.Error(w, err)
		return
	}
	response.Success(w, http.StatusOK, h.books.Search(filter))
}
