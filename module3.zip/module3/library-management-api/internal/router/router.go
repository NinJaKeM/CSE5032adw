// Package router связывает маршруты с обработчиками и подключает middleware.
package router

import (
	"net/http"
	"strings"

	"library-management-api/internal/apperr"
	"library-management-api/internal/handlers"
	"library-management-api/internal/middleware"
	"library-management-api/internal/response"
	"library-management-api/internal/services"
	"library-management-api/internal/storage"
)

// methods — HTTP-методы, по которым проверяется, существует ли маршрут с другим методом (для 405).
var methods = []string{http.MethodGet, http.MethodPost, http.MethodPut, http.MethodPatch, http.MethodDelete}

// New собирает приложение: сервисы, обработчики, маршруты и middleware.
func New(store *storage.Memory, now services.Clock) http.Handler {
	bookHandler := handlers.NewBookHandler(services.NewBookService(store, now))
	readerHandler := handlers.NewReaderHandler(services.NewReaderService(store))
	loanHandler := handlers.NewLoanHandler(services.NewLoanService(store, now), services.NewStatisticsService(store, now))

	mux := http.NewServeMux()
	registerRoutes(mux, bookHandler, readerHandler, loanHandler)

	// Порядок: Logging -> Recovery -> обработка 404/405 -> ServeMux.
	return middleware.Logging(middleware.Recovery(withNotFoundAndMethodNotAllowed(mux)))
}

// registerRoutes — таблица маршрутов (шаблоны Go 1.22: метод + путь + {id}).
func registerRoutes(mux *http.ServeMux, b *handlers.BookHandler, rd *handlers.ReaderHandler, l *handlers.LoanHandler) {
	// Books
	mux.HandleFunc("GET /api/books", b.List)
	mux.HandleFunc("GET /api/books/search", b.Search)
	mux.HandleFunc("GET /api/books/{id}", b.Get)
	mux.HandleFunc("POST /api/books", b.Create)
	mux.HandleFunc("PUT /api/books/{id}", b.Update)
	mux.HandleFunc("DELETE /api/books/{id}", b.Delete)

	// Readers
	mux.HandleFunc("GET /api/readers", rd.List)
	mux.HandleFunc("GET /api/readers/{id}", rd.Get)
	mux.HandleFunc("POST /api/readers", rd.Create)
	mux.HandleFunc("PUT /api/readers/{id}", rd.Update)
	mux.HandleFunc("DELETE /api/readers/{id}", rd.Delete)
	mux.HandleFunc("GET /api/readers/{id}/loans", rd.Loans)

	// Loans и статистика
	mux.HandleFunc("GET /api/loans", l.List)
	mux.HandleFunc("GET /api/loans/active", l.Active)
	mux.HandleFunc("GET /api/loans/{id}", l.Get)
	mux.HandleFunc("POST /api/loans", l.Issue)
	mux.HandleFunc("PUT /api/loans/{id}/return", l.Return)
	mux.HandleFunc("GET /api/statistics", l.Statistics)
}

// withNotFoundAndMethodNotAllowed возвращает 404 и 405 в едином JSON-формате вместо текстовых ответов ServeMux.
func withNotFoundAndMethodNotAllowed(mux *http.ServeMux) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if _, pattern := mux.Handler(r); pattern != "" {
			mux.ServeHTTP(w, r)
			return
		}
		if allowed := allowedMethods(mux, r); len(allowed) > 0 {
			w.Header().Set("Allow", strings.Join(allowed, ", "))
			response.Fail(w, http.StatusMethodNotAllowed, apperr.CodeMethodNotAllowed,
				"Метод "+r.Method+" не поддерживается для "+r.URL.Path+". Разрешены: "+strings.Join(allowed, ", "))
			return
		}
		response.Fail(w, http.StatusNotFound, apperr.CodeRouteNotFound, "Маршрут "+r.URL.Path+" не найден")
	})
}

// allowedMethods возвращает методы, для которых путь запроса зарегистрирован.
func allowedMethods(mux *http.ServeMux, r *http.Request) []string {
	var allowed []string
	for _, m := range methods {
		probe := r.Clone(r.Context())
		probe.Method = m
		if _, pattern := mux.Handler(probe); pattern != "" {
			allowed = append(allowed, m)
		}
	}
	return allowed
}
