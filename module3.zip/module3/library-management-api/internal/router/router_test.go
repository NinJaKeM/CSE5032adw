package router

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"library-management-api/internal/middleware"
	"library-management-api/internal/response"
	"library-management-api/internal/storage"
)

func now() time.Time { return time.Date(2026, time.November, 22, 10, 0, 0, 0, time.UTC) }

// newTestServer создаёт приложение с демонстрационными данными.
func newTestServer() http.Handler {
	store := storage.NewMemory()
	storage.Seed(store, now())
	return New(store, now)
}

// do выполняет запрос через httptest и разбирает ответ в едином формате.
func do(t *testing.T, h http.Handler, method, target, body string) (*httptest.ResponseRecorder, response.APIResponse) {
	t.Helper()
	req := httptest.NewRequest(method, target, strings.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)

	var resp response.APIResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &resp); err != nil {
		t.Fatalf("ответ не в формате JSON: %v\n%s", err, rec.Body.String())
	}
	if resp.StatusCode != rec.Code {
		t.Fatalf("statusCode в теле (%d) не совпадает с HTTP-статусом (%d)", resp.StatusCode, rec.Code)
	}
	return rec, resp
}

func errorCode(resp response.APIResponse) string {
	if resp.ErrorCode == nil {
		return ""
	}
	return *resp.ErrorCode
}

func TestGetBooksReturns200(t *testing.T) {
	rec, resp := do(t, newTestServer(), http.MethodGet, "/api/books", "")
	if rec.Code != http.StatusOK || !resp.IsSuccess {
		t.Fatalf("ожидалось 200, получено %d", rec.Code)
	}
	if books, ok := resp.Result.([]any); !ok || len(books) != 6 {
		t.Fatalf("ожидалось 6 книг, получено %v", resp.Result)
	}
}

func TestCreateBookReturns201AndInvalidInputReturns400(t *testing.T) {
	h := newTestServer()

	rec, resp := do(t, h, http.MethodPost, "/api/books",
		`{"title":"Go in Action","author":"William Kennedy","year":2015,"genre":"IT","totalCopies":2}`)
	if rec.Code != http.StatusCreated || !resp.IsSuccess {
		t.Fatalf("ожидалось 201, получено %d", rec.Code)
	}

	cases := map[string]string{
		"некорректный JSON":      `{"title": "Broken"`,
		"пустое тело":            ``,
		"нет обязательных полей": `{"title":"Only title"}`,
		"неверный тип поля":      `{"title":"T","author":"A","year":"2015","genre":"IT","totalCopies":1}`,
		"неизвестное поле":       `{"title":"T","author":"A","year":2015,"genre":"IT","totalCopies":1,"price":10}`,
	}
	for name, body := range cases {
		rec, resp := do(t, h, http.MethodPost, "/api/books", body)
		if rec.Code != http.StatusBadRequest || resp.IsSuccess {
			t.Fatalf("%s: ожидалось 400, получено %d", name, rec.Code)
		}
	}
}

func TestLoanFlowThroughHTTP(t *testing.T) {
	h := newTestServer()

	// Книга 6 («1984») имеет 1 экземпляр, и он уже выдан — 409.
	rec, resp := do(t, h, http.MethodPost, "/api/loans", `{"bookId":6,"readerId":2}`)
	if rec.Code != http.StatusConflict || errorCode(resp) != "BOOK_NOT_AVAILABLE" {
		t.Fatalf("ожидалось 409 BOOK_NOT_AVAILABLE, получено %d %s", rec.Code, errorCode(resp))
	}

	// Несуществующий читатель — 404.
	rec, resp = do(t, h, http.MethodPost, "/api/loans", `{"bookId":3,"readerId":999}`)
	if rec.Code != http.StatusNotFound || errorCode(resp) != "READER_NOT_FOUND" {
		t.Fatalf("ожидалось 404 READER_NOT_FOUND, получено %d %s", rec.Code, errorCode(resp))
	}

	// Выдача доступной книги — 201, затем возврат — 200, повторный возврат — 409.
	rec, resp = do(t, h, http.MethodPost, "/api/loans", `{"bookId":3,"readerId":2}`)
	if rec.Code != http.StatusCreated {
		t.Fatalf("ожидалось 201, получено %d", rec.Code)
	}
	loanID := int(resp.Result.(map[string]any)["id"].(float64))
	target := "/api/loans/" + itoa(loanID) + "/return"

	if rec, _ = do(t, h, http.MethodPut, target, ""); rec.Code != http.StatusOK {
		t.Fatalf("возврат: ожидалось 200, получено %d", rec.Code)
	}
	rec, resp = do(t, h, http.MethodPut, target, "")
	if rec.Code != http.StatusConflict || errorCode(resp) != "LOAN_ALREADY_RETURNED" {
		t.Fatalf("повторный возврат: ожидалось 409, получено %d %s", rec.Code, errorCode(resp))
	}
}

func TestRoutingErrors(t *testing.T) {
	h := newTestServer()

	rec, resp := do(t, h, http.MethodGet, "/api/unknown", "")
	if rec.Code != http.StatusNotFound || errorCode(resp) != "ROUTE_NOT_FOUND" {
		t.Fatalf("неизвестный маршрут: ожидалось 404, получено %d", rec.Code)
	}

	rec, resp = do(t, h, http.MethodPatch, "/api/books/1", "")
	if rec.Code != http.StatusMethodNotAllowed || errorCode(resp) != "METHOD_NOT_ALLOWED" {
		t.Fatalf("неподдерживаемый метод: ожидалось 405, получено %d", rec.Code)
	}
	if allow := rec.Header().Get("Allow"); !strings.Contains(allow, "GET") || !strings.Contains(allow, "DELETE") {
		t.Fatalf("неверный заголовок Allow: %q", allow)
	}

	rec, resp = do(t, h, http.MethodGet, "/api/books/abc", "")
	if rec.Code != http.StatusBadRequest || errorCode(resp) != "INVALID_ID" {
		t.Fatalf("нечисловой id: ожидалось 400, получено %d", rec.Code)
	}

	rec, _ = do(t, h, http.MethodGet, "/api/books/search?author=martin&genre=IT", "")
	if rec.Code != http.StatusOK {
		t.Fatalf("поиск: ожидалось 200, получено %d", rec.Code)
	}
}

func TestRecoveryMiddlewareReturns500WithoutDetails(t *testing.T) {
	panicking := http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
		panic("database connection string: secret")
	})
	h := middleware.Logging(middleware.Recovery(panicking))

	rec, resp := do(t, h, http.MethodGet, "/api/books", "")
	if rec.Code != http.StatusInternalServerError || errorCode(resp) != "INTERNAL_SERVER_ERROR" {
		t.Fatalf("ожидалось 500, получено %d", rec.Code)
	}
	if strings.Contains(rec.Body.String(), "secret") {
		t.Fatal("в ответ попали технические детали ошибки")
	}
}

func itoa(n int) string {
	b, _ := json.Marshal(n)
	return string(b)
}
