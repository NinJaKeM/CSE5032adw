// Package apperr описывает ошибки приложения с HTTP-статусом и кодом ошибки.
package apperr

import "net/http"

// Коды ошибок, возвращаемые в поле errorCode.
const (
	CodeInvalidJSON            = "INVALID_JSON"
	CodeValidation             = "VALIDATION_ERROR"
	CodeInvalidID              = "INVALID_ID"
	CodeInvalidQuery           = "INVALID_QUERY"
	CodeBookNotFound           = "BOOK_NOT_FOUND"
	CodeReaderNotFound         = "READER_NOT_FOUND"
	CodeLoanNotFound           = "LOAN_NOT_FOUND"
	CodeEmailExists            = "EMAIL_ALREADY_EXISTS"
	CodeBookNotAvailable       = "BOOK_NOT_AVAILABLE"
	CodeReaderInactive         = "READER_INACTIVE"
	CodeLoanLimitExceeded      = "LOAN_LIMIT_EXCEEDED"
	CodeLoanAlreadyReturned    = "LOAN_ALREADY_RETURNED"
	CodeBookHasActiveLoans     = "BOOK_HAS_ACTIVE_LOANS"
	CodeReaderHasActiveLoans   = "READER_HAS_ACTIVE_LOANS"
	CodeCopiesLessThanBorrowed = "COPIES_LESS_THAN_BORROWED"
	CodeRouteNotFound          = "ROUTE_NOT_FOUND"
	CodeMethodNotAllowed       = "METHOD_NOT_ALLOWED"
	CodeInternal               = "INTERNAL_SERVER_ERROR"
)

// Error — ошибка приложения, которую обработчик превращает в HTTP-ответ.
type Error struct {
	Status  int
	Code    string
	Message string
}

func (e *Error) Error() string {
	return e.Code + ": " + e.Message
}

// New создаёт ошибку с произвольным статусом.
func New(status int, code, message string) *Error {
	return &Error{Status: status, Code: code, Message: message}
}

// BadRequest — 400, некорректные входные данные.
func BadRequest(code, message string) *Error {
	return New(http.StatusBadRequest, code, message)
}

// NotFound — 404, ресурс не существует.
func NotFound(code, message string) *Error {
	return New(http.StatusNotFound, code, message)
}

// Conflict — 409, нарушение бизнес-правила.
func Conflict(code, message string) *Error {
	return New(http.StatusConflict, code, message)
}
