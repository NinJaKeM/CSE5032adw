// Package middleware содержит промежуточные обработчики HTTP: логирование и восстановление после паники.
package middleware

import (
	"log"
	"net/http"
	"runtime/debug"
	"time"

	"library-management-api/internal/apperr"
	"library-management-api/internal/response"
)

// statusRecorder запоминает HTTP-статус и размер ответа для журнала.
type statusRecorder struct {
	http.ResponseWriter
	status int
	bytes  int
}

func (rec *statusRecorder) WriteHeader(status int) {
	rec.status = status
	rec.ResponseWriter.WriteHeader(status)
}

func (rec *statusRecorder) Write(b []byte) (int, error) {
	if rec.status == 0 {
		rec.status = http.StatusOK
	}
	n, err := rec.ResponseWriter.Write(b)
	rec.bytes += n
	return n, err
}

// Logging записывает в журнал каждый HTTP-запрос: метод, путь, статус, размер и время обработки.
func Logging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &statusRecorder{ResponseWriter: w}
		next.ServeHTTP(rec, r)
		if rec.status == 0 {
			rec.status = http.StatusOK
		}
		level := "INFO "
		switch {
		case rec.status >= 500:
			level = "ERROR"
		case rec.status >= 400:
			level = "WARN "
		}
		log.Printf("%s %s %s -> %d (%d B, %s) from %s",
			level, r.Method, r.URL.RequestURI(), rec.status, rec.bytes, time.Since(start).Round(time.Microsecond), r.RemoteAddr)
	})
}

// Recovery перехватывает панику в обработчике: подробности (stack trace) пишутся в журнал,
// клиент получает 500 INTERNAL_SERVER_ERROR без технических деталей.
func Recovery(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if p := recover(); p != nil {
				log.Printf("ERROR panic in %s %s: %v\n%s", r.Method, r.URL.Path, p, debug.Stack())
				response.Fail(w, http.StatusInternalServerError, apperr.CodeInternal, "Внутренняя ошибка сервера")
			}
		}()
		next.ServeHTTP(w, r)
	})
}
