// Package storage хранит данные приложения в оперативной памяти.
package storage

import (
	"sync"

	"library-management-api/internal/models"
)

// Data — все данные библиотеки. Доступ к ним возможен только через Memory.Read / Memory.Write.
type Data struct {
	Books   map[int]models.Book
	Readers map[int]models.Reader
	Loans   map[int]models.Loan

	lastBookID   int
	lastReaderID int
	lastLoanID   int
}

// NextBookID выдаёт следующий идентификатор книги.
func (d *Data) NextBookID() int {
	d.lastBookID++
	return d.lastBookID
}

// NextReaderID выдаёт следующий идентификатор читателя.
func (d *Data) NextReaderID() int {
	d.lastReaderID++
	return d.lastReaderID
}

// NextLoanID выдаёт следующий идентификатор выдачи.
func (d *Data) NextLoanID() int {
	d.lastLoanID++
	return d.lastLoanID
}

// Memory — потокобезопасное хранилище. HTTP-сервер обрабатывает запросы конкурентно,
// поэтому все обращения к картам защищены sync.RWMutex: чтение — RLock, изменение — Lock.
type Memory struct {
	mu   sync.RWMutex
	data *Data
}

// NewMemory создаёт пустое хранилище.
func NewMemory() *Memory {
	return &Memory{
		data: &Data{
			Books:   make(map[int]models.Book),
			Readers: make(map[int]models.Reader),
			Loans:   make(map[int]models.Loan),
		},
	}
}

// Read выполняет fn под блокировкой на чтение (несколько читателей одновременно).
func (m *Memory) Read(fn func(d *Data)) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	fn(m.data)
}

// Write выполняет fn под эксклюзивной блокировкой. Проверка бизнес-правил и изменение данных
// внутри fn выполняются атомарно, поэтому два параллельных запроса не выдадут один экземпляр дважды.
func (m *Memory) Write(fn func(d *Data) error) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	return fn(m.data)
}
