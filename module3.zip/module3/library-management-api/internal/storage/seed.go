package storage

import (
	"time"

	"library-management-api/internal/models"
)

const day = 24 * time.Hour

// Seed заполняет хранилище демонстрационными данными. Даты выдач считаются от now,
// а доступные экземпляры вычисляются по активным выдачам — статистика всегда согласована.
func Seed(m *Memory, now time.Time) {
	_ = m.Write(func(d *Data) error {
		books := []models.Book{
			{Title: "Clean Code", Author: "Robert Martin", Year: 2008, Genre: "IT", TotalCopies: 3},
			{Title: "Clean Architecture", Author: "Robert Martin", Year: 2017, Genre: "IT", TotalCopies: 2},
			{Title: "The Go Programming Language", Author: "Alan Donovan", Year: 2015, Genre: "IT", TotalCopies: 4},
			{Title: "Путь Абая", Author: "Мухтар Ауэзов", Year: 1942, Genre: "Роман", TotalCopies: 3},
			{Title: "Мастер и Маргарита", Author: "Михаил Булгаков", Year: 1967, Genre: "Роман", TotalCopies: 2},
			{Title: "1984", Author: "George Orwell", Year: 1949, Genre: "Антиутопия", TotalCopies: 1},
		}
		for _, b := range books {
			b.ID = d.NextBookID()
			b.AvailableCopies = b.TotalCopies
			d.Books[b.ID] = b
		}

		readers := []models.Reader{
			{FirstName: "Иван", LastName: "Иванов", Email: "ivan.ivanov@mail.kz", Age: 20, IsActive: true},
			{FirstName: "Анна", LastName: "Петрова", Email: "anna.petrova@mail.kz", Age: 22, IsActive: true},
			{FirstName: "Максим", LastName: "Ким", Email: "maxim.kim@mail.kz", Age: 19, IsActive: true},
			{FirstName: "Алия", LastName: "Сейтказы", Email: "aliya.seitkazy@mail.kz", Age: 21, IsActive: false},
		}
		for _, r := range readers {
			r.ID = d.NextReaderID()
			d.Readers[r.ID] = r
		}

		// {bookID, readerID, дней назад выдана, срок в днях, дней назад возвращена (-1 — не возвращена)}
		history := [][5]int{
			{1, 1, 150, 14, 140},
			{1, 2, 120, 14, 110},
			{3, 1, 95, 14, 85},
			{1, 3, 60, 14, 50},
			{5, 2, 45, 14, 35},
			{3, 2, 30, 14, 20},
			{6, 1, 20, 14, -1}, // просроченная выдача
			{1, 2, 5, 14, -1},
			{2, 3, 3, 14, -1},
			{4, 1, 1, 14, -1},
		}
		for _, h := range history {
			borrowed := now.Add(-time.Duration(h[2]) * day)
			loan := models.Loan{
				ID:         d.NextLoanID(),
				BookID:     h[0],
				ReaderID:   h[1],
				BorrowedAt: borrowed,
				DueDate:    borrowed.Add(time.Duration(h[3]) * day),
			}
			if h[4] >= 0 {
				loan.MarkReturned(now.Add(-time.Duration(h[4]) * day))
			} else {
				book := d.Books[loan.BookID]
				book.TakeCopy()
				d.Books[loan.BookID] = book
			}
			d.Loans[loan.ID] = loan
		}
		return nil
	})
}
