package models

import "time"

// Loan — операция выдачи книги читателю.
type Loan struct {
	ID         int        `json:"id"`
	BookID     int        `json:"bookId"`
	ReaderID   int        `json:"readerId"`
	BorrowedAt time.Time  `json:"borrowedAt"`
	DueDate    time.Time  `json:"dueDate"`
	ReturnedAt *time.Time `json:"returnedAt"` // nil, пока книга не возвращена
	IsReturned bool       `json:"isReturned"`
}

// IsActive сообщает, что книга ещё не возвращена.
func (l Loan) IsActive() bool {
	return !l.IsReturned
}

// IsOverdue сообщает, что активная выдача просрочена на момент now.
func (l Loan) IsOverdue(now time.Time) bool {
	return !l.IsReturned && now.After(l.DueDate)
}

// MarkReturned отмечает возврат книги (изменение через указатель).
func (l *Loan) MarkReturned(at time.Time) {
	l.IsReturned = true
	l.ReturnedAt = &at
}

// LoanInput — тело запроса POST /api/loans.
type LoanInput struct {
	BookID   *int `json:"bookId"`
	ReaderID *int `json:"readerId"`
	Days     *int `json:"days"` // необязательное: срок выдачи в днях, по умолчанию 14
}
