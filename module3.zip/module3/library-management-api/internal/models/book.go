package models

// Book — книга в фонде библиотеки.
type Book struct {
	ID              int    `json:"id"`
	Title           string `json:"title"`
	Author          string `json:"author"`
	Year            int    `json:"year"`
	Genre           string `json:"genre"`
	TotalCopies     int    `json:"totalCopies"`
	AvailableCopies int    `json:"availableCopies"`
}

// BorrowedCopies возвращает количество экземпляров, находящихся у читателей.
func (b Book) BorrowedCopies() int {
	return b.TotalCopies - b.AvailableCopies
}

// TakeCopy уменьшает количество доступных экземпляров (изменение через указатель).
// Возвращает false, если доступных экземпляров нет.
func (b *Book) TakeCopy() bool {
	if b.AvailableCopies <= 0 {
		return false
	}
	b.AvailableCopies--
	return true
}

// ReturnCopy увеличивает количество доступных экземпляров, не превышая общее количество.
func (b *Book) ReturnCopy() {
	if b.AvailableCopies < b.TotalCopies {
		b.AvailableCopies++
	}
}

// BookInput — тело запроса POST/PUT /api/books.
// Указатели позволяют отличить отсутствующее поле от нулевого значения.
type BookInput struct {
	Title       *string `json:"title"`
	Author      *string `json:"author"`
	Year        *int    `json:"year"`
	Genre       *string `json:"genre"`
	TotalCopies *int    `json:"totalCopies"`
}

// BookFilter — параметры фильтрации GET /api/books/search.
type BookFilter struct {
	Title  string
	Author string
	Genre  string
	Year   int // 0 — фильтр по году не задан
}
