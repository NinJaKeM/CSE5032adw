package models

// Reader — читатель библиотеки.
type Reader struct {
	ID        int    `json:"id"`
	FirstName string `json:"firstName"`
	LastName  string `json:"lastName"`
	Email     string `json:"email"`
	Age       int    `json:"age"`
	IsActive  bool   `json:"isActive"`
}

// FullName возвращает имя и фамилию читателя.
func (r Reader) FullName() string {
	return r.FirstName + " " + r.LastName
}

// ReaderInput — тело запроса POST/PUT /api/readers.
type ReaderInput struct {
	FirstName *string `json:"firstName"`
	LastName  *string `json:"lastName"`
	Email     *string `json:"email"`
	Age       *int    `json:"age"`
	IsActive  *bool   `json:"isActive"` // необязательное: при создании по умолчанию true
}
