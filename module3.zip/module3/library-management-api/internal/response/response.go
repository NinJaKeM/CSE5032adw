// Package response формирует HTTP-ответы API в едином формате.
package response

import (
	"encoding/json"
	"errors"
	"log"
	"net/http"

	"library-management-api/internal/apperr"
)

// APIResponse — единый формат всех ответов API.
type APIResponse struct {
	StatusCode   int     `json:"statusCode"`
	IsSuccess    bool    `json:"isSuccess"`
	Result       any     `json:"result"`
	ErrorCode    *string `json:"errorCode"`
	ErrorMessage *string `json:"errorMessage"`
}

// Success отправляет успешный ответ (200, 201).
func Success(w http.ResponseWriter, status int, result any) {
	write(w, status, APIResponse{StatusCode: status, IsSuccess: true, Result: result})
}

// Fail отправляет ответ с ошибкой.
func Fail(w http.ResponseWriter, status int, code, message string) {
	write(w, status, APIResponse{StatusCode: status, IsSuccess: false, ErrorCode: &code, ErrorMessage: &message})
}

// Error отправляет ошибку приложения; неизвестная ошибка превращается в 500 без технических деталей.
func Error(w http.ResponseWriter, err error) {
	var appErr *apperr.Error
	if errors.As(err, &appErr) {
		Fail(w, appErr.Status, appErr.Code, appErr.Message)
		return
	}
	log.Printf("ERROR unexpected error: %v", err)
	Fail(w, http.StatusInternalServerError, apperr.CodeInternal, "Внутренняя ошибка сервера")
}

func write(w http.ResponseWriter, status int, body APIResponse) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	if err := enc.Encode(body); err != nil {
		log.Printf("ERROR write response: %v", err)
	}
}
