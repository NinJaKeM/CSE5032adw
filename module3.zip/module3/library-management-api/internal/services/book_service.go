package services

import (
	"strconv"
	"strings"

	"library-management-api/internal/apperr"
	"library-management-api/internal/models"
	"library-management-api/internal/storage"
)

// BookService — операции с книгами.
type BookService struct {
	store *storage.Memory
	now   Clock
}

// NewBookService создаёт сервис книг.
func NewBookService(store *storage.Memory, now Clock) *BookService {
	return &BookService{store: store, now: now}
}

// List возвращает все книги, упорядоченные по ID.
func (s *BookService) List() []models.Book {
	var books []models.Book
	s.store.Read(func(d *storage.Data) {
		books = make([]models.Book, 0, len(d.Books))
		for _, b := range d.Books {
			books = append(books, b)
		}
	})
	sortBooksByID(books)
	return books
}

// Get возвращает книгу по ID.
func (s *BookService) Get(id int) (*models.Book, error) {
	var book *models.Book
	var err error
	s.store.Read(func(d *storage.Data) {
		book, err = findBook(d, id)
	})
	return book, err
}

// Create добавляет книгу; все экземпляры новой книги доступны.
func (s *BookService) Create(in models.BookInput) (*models.Book, error) {
	if err := s.validate(in); err != nil {
		return nil, err
	}
	var created models.Book
	err := s.store.Write(func(d *storage.Data) error {
		created = models.Book{ID: d.NextBookID()}
		applyBookInput(&created, in)
		created.AvailableCopies = created.TotalCopies
		d.Books[created.ID] = created
		return nil
	})
	return &created, err
}

// Update изменяет книгу. Общее количество экземпляров нельзя сделать меньше числа выданных.
func (s *BookService) Update(id int, in models.BookInput) (*models.Book, error) {
	if err := s.validate(in); err != nil {
		return nil, err
	}
	var updated *models.Book
	err := s.store.Write(func(d *storage.Data) error {
		book, err := findBook(d, id)
		if err != nil {
			return err
		}
		borrowed := book.BorrowedCopies()
		if *in.TotalCopies < borrowed {
			return apperr.Conflict(apperr.CodeCopiesLessThanBorrowed,
				"Общее количество экземпляров не может быть меньше выданных ("+strconv.Itoa(borrowed)+")")
		}
		applyBookInput(book, in)
		book.AvailableCopies = book.TotalCopies - borrowed
		d.Books[id] = *book
		updated = book
		return nil
	})
	return updated, err
}

// Delete удаляет книгу, если по ней нет активных выдач.
func (s *BookService) Delete(id int) error {
	return s.store.Write(func(d *storage.Data) error {
		if _, err := findBook(d, id); err != nil {
			return err
		}
		active := countActiveLoans(d, func(l models.Loan) bool { return l.BookID == id })
		if active > 0 {
			return apperr.Conflict(apperr.CodeBookHasActiveLoans,
				"Нельзя удалить книгу: есть активные выдачи ("+strconv.Itoa(active)+")")
		}
		delete(d.Books, id)
		return nil
	})
}

// Search фильтрует книги по названию, автору, жанру и году издания.
func (s *BookService) Search(filter models.BookFilter) []models.Book {
	result := make([]models.Book, 0)
	s.store.Read(func(d *storage.Data) {
		for _, b := range d.Books {
			if matchesBookFilter(b, filter) {
				result = append(result, b)
			}
		}
	})
	sortBooksByID(result)
	return result
}

// ParseBookFilter разбирает query-параметры поиска; year должен быть целым числом.
func ParseBookFilter(title, author, genre, year string) (models.BookFilter, error) {
	filter := models.BookFilter{
		Title:  strings.TrimSpace(title),
		Author: strings.TrimSpace(author),
		Genre:  strings.TrimSpace(genre),
	}
	if year = strings.TrimSpace(year); year != "" {
		y, err := strconv.Atoi(year)
		if err != nil || y <= 0 {
			return filter, apperr.BadRequest(apperr.CodeInvalidQuery, "Параметр year должен быть положительным целым числом")
		}
		filter.Year = y
	}
	return filter, nil
}

// matchesBookFilter проверяет книгу по всем заданным условиям фильтра (логическое И).
func matchesBookFilter(b models.Book, f models.BookFilter) bool {
	if f.Title != "" && !containsFold(b.Title, f.Title) {
		return false
	}
	if f.Author != "" && !containsFold(b.Author, f.Author) {
		return false
	}
	if f.Genre != "" && !strings.EqualFold(b.Genre, f.Genre) {
		return false
	}
	if f.Year != 0 && b.Year != f.Year {
		return false
	}
	return true
}

// applyBookInput копирует поля запроса в книгу через указатель.
func applyBookInput(b *models.Book, in models.BookInput) {
	b.Title = strings.TrimSpace(*in.Title)
	b.Author = strings.TrimSpace(*in.Author)
	b.Year = *in.Year
	b.Genre = strings.TrimSpace(*in.Genre)
	b.TotalCopies = *in.TotalCopies
}

// validate проверяет обязательные поля и диапазоны значений книги.
func (s *BookService) validate(in models.BookInput) error {
	var problems []string
	problems = requireText(problems, "title", in.Title, MaxTitleLength)
	problems = requireText(problems, "author", in.Author, MaxNameLength)
	problems = requireText(problems, "genre", in.Genre, MaxNameLength)
	problems = requireIntRange(problems, "year", in.Year, MinBookYear, s.now().Year())
	problems = requireIntRange(problems, "totalCopies", in.TotalCopies, 1, MaxTotalCopies)
	return validationError(problems)
}
