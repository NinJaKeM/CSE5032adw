// Package services содержит бизнес-логику: валидацию, поиск, расчёты и бизнес-правила.
package services

import (
	"sort"
	"strings"
	"time"

	"library-management-api/internal/apperr"
	"library-management-api/internal/models"
	"library-management-api/internal/storage"
)

// Ограничения бизнес-правил и валидации.
const (
	MaxActiveLoansPerReader = 5  // не более пяти активных выдач у одного читателя
	DefaultLoanDays         = 14 // срок выдачи по умолчанию
	MaxLoanDays             = 60 // максимальный срок выдачи
	MinBookYear             = 1450
	MaxTotalCopies          = 1000
	MinReaderAge            = 6
	MaxReaderAge            = 120
	MaxNameLength           = 100
	MaxTitleLength          = 200
)

// Clock возвращает текущее время; в тестах подменяется фиксированным значением.
type Clock func() time.Time

// findBook ищет книгу и возвращает указатель на её копию, которую можно изменить и сохранить.
func findBook(d *storage.Data, id int) (*models.Book, error) {
	book, ok := d.Books[id]
	if !ok {
		return nil, apperr.NotFound(apperr.CodeBookNotFound, "Книга не найдена")
	}
	return &book, nil
}

// findReader ищет читателя и возвращает указатель на его копию.
func findReader(d *storage.Data, id int) (*models.Reader, error) {
	reader, ok := d.Readers[id]
	if !ok {
		return nil, apperr.NotFound(apperr.CodeReaderNotFound, "Читатель не найден")
	}
	return &reader, nil
}

// findLoan ищет операцию выдачи и возвращает указатель на её копию.
func findLoan(d *storage.Data, id int) (*models.Loan, error) {
	loan, ok := d.Loans[id]
	if !ok {
		return nil, apperr.NotFound(apperr.CodeLoanNotFound, "Выдача не найдена")
	}
	return &loan, nil
}

// countActiveLoans считает активные выдачи, удовлетворяющие условию match.
func countActiveLoans(d *storage.Data, match func(l models.Loan) bool) int {
	count := 0
	for _, loan := range d.Loans {
		if loan.IsActive() && match(loan) {
			count++
		}
	}
	return count
}

// containsFold проверяет вхождение подстроки без учёта регистра.
func containsFold(s, substr string) bool {
	return strings.Contains(strings.ToLower(s), strings.ToLower(substr))
}

// sortBooksByID упорядочивает срез книг по идентификатору (порядок обхода map в Go случаен).
func sortBooksByID(books []models.Book) {
	sort.Slice(books, func(i, j int) bool { return books[i].ID < books[j].ID })
}

// sortReadersByID упорядочивает срез читателей по идентификатору.
func sortReadersByID(readers []models.Reader) {
	sort.Slice(readers, func(i, j int) bool { return readers[i].ID < readers[j].ID })
}

// sortLoansByID упорядочивает срез выдач по идентификатору.
func sortLoansByID(loans []models.Loan) {
	sort.Slice(loans, func(i, j int) bool { return loans[i].ID < loans[j].ID })
}

// validationError собирает сообщения о некорректных полях в одну ошибку 400.
func validationError(problems []string) error {
	if len(problems) == 0 {
		return nil
	}
	return apperr.BadRequest(apperr.CodeValidation, "Некорректные данные: "+strings.Join(problems, "; "))
}

// requireText проверяет обязательное строковое поле и его длину.
func requireText(problems []string, field string, value *string, maxLen int) []string {
	switch {
	case value == nil:
		return append(problems, field+" — обязательное поле")
	case strings.TrimSpace(*value) == "":
		return append(problems, field+" не может быть пустым")
	case len([]rune(strings.TrimSpace(*value))) > maxLen:
		return append(problems, field+" не может быть длиннее "+itoa(maxLen)+" символов")
	}
	return problems
}

// requireIntRange проверяет обязательное целое поле и диапазон значений.
func requireIntRange(problems []string, field string, value *int, min, max int) []string {
	if value == nil {
		return append(problems, field+" — обязательное поле")
	}
	if *value < min || *value > max {
		return append(problems, field+" должно быть в диапазоне от "+itoa(min)+" до "+itoa(max))
	}
	return problems
}
