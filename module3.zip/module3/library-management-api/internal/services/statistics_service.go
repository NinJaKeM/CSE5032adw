package services

import (
	"math"
	"sort"

	"library-management-api/internal/models"
	"library-management-api/internal/storage"
)

// TopBooksCount — сколько книг выводится в рейтинге самых выдаваемых.
const TopBooksCount = 3

var monthNames = [12]string{
	"Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
	"Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
}

// TopBook — книга в рейтинге выдач.
type TopBook struct {
	BookID    int    `json:"bookId"`
	Title     string `json:"title"`
	Author    string `json:"author"`
	LoanCount int    `json:"loanCount"`
}

// MonthStat — количество выдач за месяц.
type MonthStat struct {
	Month int    `json:"month"`
	Name  string `json:"name"`
	Count int    `json:"count"`
}

// Statistics — статистика библиотеки (GET /api/statistics).
type Statistics struct {
	TotalBooks          int         `json:"totalBooks"`
	TotalCopies         int         `json:"totalCopies"`
	AvailableCopies     int         `json:"availableCopies"`
	BorrowedCopies      int         `json:"borrowedCopies"`
	AvailabilityPercent float64     `json:"availabilityPercent"`
	TotalReaders        int         `json:"totalReaders"`
	ActiveReaders       int         `json:"activeReaders"`
	TotalLoans          int         `json:"totalLoans"`
	ActiveLoans         int         `json:"activeLoans"`
	OverdueLoans        int         `json:"overdueLoans"`
	TopBooks            []TopBook   `json:"topBooks"`
	LoansByMonth        []MonthStat `json:"loansByMonth"`
}

// StatisticsService вычисляет статистику по текущим данным приложения.
type StatisticsService struct {
	store *storage.Memory
	now   Clock
}

// NewStatisticsService создаёт сервис статистики.
func NewStatisticsService(store *storage.Memory, now Clock) *StatisticsService {
	return &StatisticsService{store: store, now: now}
}

// Get вычисляет статистику под блокировкой на чтение.
func (s *StatisticsService) Get() Statistics {
	var st Statistics
	now := s.now()
	s.store.Read(func(d *storage.Data) {
		st.TotalBooks = len(d.Books)
		for _, b := range d.Books {
			st.TotalCopies += b.TotalCopies
			st.AvailableCopies += b.AvailableCopies
		}
		st.BorrowedCopies = st.TotalCopies - st.AvailableCopies
		st.AvailabilityPercent = availabilityPercent(st.AvailableCopies, st.TotalCopies)

		st.TotalReaders = len(d.Readers)
		for _, r := range d.Readers {
			if r.IsActive {
				st.ActiveReaders++
			}
		}

		loans := make([]models.Loan, 0, len(d.Loans))
		for _, l := range d.Loans {
			loans = append(loans, l)
			if l.IsActive() {
				st.ActiveLoans++
			}
			if l.IsOverdue(now) {
				st.OverdueLoans++
			}
		}
		st.TotalLoans = len(loans)
		st.TopBooks = topBooks(d, loans, TopBooksCount)
		st.LoansByMonth = monthStats(loansByMonth(loans))
	})
	return st
}

// availabilityPercent — доля доступных экземпляров в процентах (float64, два знака после запятой).
func availabilityPercent(available, total int) float64 {
	if total == 0 {
		return 0
	}
	return math.Round(float64(available)/float64(total)*100*100) / 100
}

// loansByMonth считает выдачи по месяцу даты выдачи: индекс 0 — январь, 11 — декабрь.
func loansByMonth(loans []models.Loan) [12]int {
	var counts [12]int
	for _, l := range loans {
		counts[l.BorrowedAt.Month()-1]++
	}
	return counts
}

// monthStats превращает массив [12]int в список с названиями месяцев.
func monthStats(counts [12]int) []MonthStat {
	stats := make([]MonthStat, 0, len(counts))
	for i, c := range counts {
		stats = append(stats, MonthStat{Month: i + 1, Name: monthNames[i], Count: c})
	}
	return stats
}

// topBooks возвращает n книг с наибольшим количеством выдач (при равенстве — меньший ID).
func topBooks(d *storage.Data, loans []models.Loan, n int) []TopBook {
	counts := make(map[int]int)
	for _, l := range loans {
		counts[l.BookID]++
	}
	top := make([]TopBook, 0, len(counts))
	for bookID, count := range counts {
		item := TopBook{BookID: bookID, LoanCount: count}
		if b, ok := d.Books[bookID]; ok {
			item.Title, item.Author = b.Title, b.Author
		} else {
			item.Title = "(книга удалена)"
		}
		top = append(top, item)
	}
	sort.Slice(top, func(i, j int) bool {
		if top[i].LoanCount != top[j].LoanCount {
			return top[i].LoanCount > top[j].LoanCount
		}
		return top[i].BookID < top[j].BookID
	})
	if len(top) > n {
		top = top[:n]
	}
	return top
}
