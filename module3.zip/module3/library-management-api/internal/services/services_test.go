package services

import (
	"errors"
	"net/http"
	"sync"
	"testing"
	"time"

	"library-management-api/internal/apperr"
	"library-management-api/internal/models"
	"library-management-api/internal/storage"
)

var fixedNow = time.Date(2026, time.November, 22, 10, 0, 0, 0, time.UTC)

func clock() time.Time { return fixedNow }

func strPtr(s string) *string { return &s }
func intPtr(n int) *int       { return &n }

// setup создаёт хранилище с одной книгой (copies экземпляров) и одним активным читателем.
func setup(t *testing.T, copies int) (*storage.Memory, *models.Book, *models.Reader) {
	t.Helper()
	store := storage.NewMemory()
	book, err := NewBookService(store, clock).Create(models.BookInput{
		Title: strPtr("Clean Code"), Author: strPtr("Robert Martin"), Year: intPtr(2008),
		Genre: strPtr("IT"), TotalCopies: intPtr(copies),
	})
	if err != nil {
		t.Fatalf("create book: %v", err)
	}
	reader, err := NewReaderService(store).Create(models.ReaderInput{
		FirstName: strPtr("Ivan"), LastName: strPtr("Ivanov"), Email: strPtr("ivan@mail.kz"), Age: intPtr(20),
	})
	if err != nil {
		t.Fatalf("create reader: %v", err)
	}
	return store, book, reader
}

// assertAppError проверяет HTTP-статус и код ошибки приложения.
func assertAppError(t *testing.T, err error, status int, code string) {
	t.Helper()
	var appErr *apperr.Error
	if !errors.As(err, &appErr) {
		t.Fatalf("ожидалась ошибка %s, получено %v", code, err)
	}
	if appErr.Status != status || appErr.Code != code {
		t.Fatalf("ожидалось %d %s, получено %d %s", status, code, appErr.Status, appErr.Code)
	}
}

func TestIssueLoanDecreasesAndReturnIncreasesAvailableCopies(t *testing.T) {
	store, book, reader := setup(t, 2)
	loans := NewLoanService(store, clock)
	books := NewBookService(store, clock)

	loan, err := loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &reader.ID})
	if err != nil {
		t.Fatalf("issue: %v", err)
	}
	if got, _ := books.Get(book.ID); got.AvailableCopies != 1 {
		t.Fatalf("после выдачи ожидался 1 доступный экземпляр, получено %d", got.AvailableCopies)
	}
	if !loan.DueDate.Equal(fixedNow.AddDate(0, 0, DefaultLoanDays)) {
		t.Fatalf("неверный срок возврата: %v", loan.DueDate)
	}

	returned, err := loans.Return(loan.ID)
	if err != nil {
		t.Fatalf("return: %v", err)
	}
	if !returned.IsReturned || returned.ReturnedAt == nil {
		t.Fatalf("выдача не отмечена как возвращённая: %+v", returned)
	}
	if got, _ := books.Get(book.ID); got.AvailableCopies != 2 {
		t.Fatalf("после возврата ожидалось 2 доступных экземпляра, получено %d", got.AvailableCopies)
	}

	_, err = loans.Return(loan.ID)
	assertAppError(t, err, http.StatusConflict, apperr.CodeLoanAlreadyReturned)
}

func TestIssueLoanBusinessRules(t *testing.T) {
	store, book, reader := setup(t, 1)
	loans := NewLoanService(store, clock)
	missing := 999

	_, err := loans.Issue(models.LoanInput{BookID: &missing, ReaderID: &reader.ID})
	assertAppError(t, err, http.StatusNotFound, apperr.CodeBookNotFound)

	_, err = loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &missing})
	assertAppError(t, err, http.StatusNotFound, apperr.CodeReaderNotFound)

	if _, err = loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &reader.ID}); err != nil {
		t.Fatalf("первая выдача: %v", err)
	}
	_, err = loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &reader.ID})
	assertAppError(t, err, http.StatusConflict, apperr.CodeBookNotAvailable)

	inactive, err := NewReaderService(store).Create(models.ReaderInput{
		FirstName: strPtr("Anna"), LastName: strPtr("Petrova"), Email: strPtr("anna@mail.kz"),
		Age: intPtr(22), IsActive: new(bool),
	})
	if err != nil {
		t.Fatalf("create inactive reader: %v", err)
	}
	_, err = loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &inactive.ID})
	assertAppError(t, err, http.StatusConflict, apperr.CodeReaderInactive)

	_, err = loans.Issue(models.LoanInput{BookID: &book.ID})
	assertAppError(t, err, http.StatusBadRequest, apperr.CodeValidation)
}

func TestReaderCannotHaveMoreThanFiveActiveLoans(t *testing.T) {
	store, book, reader := setup(t, 10)
	loans := NewLoanService(store, clock)
	for i := 0; i < MaxActiveLoansPerReader; i++ {
		if _, err := loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &reader.ID}); err != nil {
			t.Fatalf("выдача %d: %v", i+1, err)
		}
	}
	_, err := loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &reader.ID})
	assertAppError(t, err, http.StatusConflict, apperr.CodeLoanLimitExceeded)
}

func TestCannotDeleteBookOrReaderWithActiveLoans(t *testing.T) {
	store, book, reader := setup(t, 1)
	loan, err := NewLoanService(store, clock).Issue(models.LoanInput{BookID: &book.ID, ReaderID: &reader.ID})
	if err != nil {
		t.Fatalf("issue: %v", err)
	}
	assertAppError(t, NewBookService(store, clock).Delete(book.ID), http.StatusConflict, apperr.CodeBookHasActiveLoans)
	assertAppError(t, NewReaderService(store).Delete(reader.ID), http.StatusConflict, apperr.CodeReaderHasActiveLoans)

	if _, err := NewLoanService(store, clock).Return(loan.ID); err != nil {
		t.Fatalf("return: %v", err)
	}
	if err := NewBookService(store, clock).Delete(book.ID); err != nil {
		t.Fatalf("после возврата книгу можно удалить: %v", err)
	}
}

func TestReaderEmailMustBeUnique(t *testing.T) {
	store, _, _ := setup(t, 1)
	_, err := NewReaderService(store).Create(models.ReaderInput{
		FirstName: strPtr("Ivan"), LastName: strPtr("Petrov"), Email: strPtr("  IVAN@mail.kz "), Age: intPtr(30),
	})
	assertAppError(t, err, http.StatusConflict, apperr.CodeEmailExists)
}

func TestSearchBooksFiltersByAuthorGenreAndYear(t *testing.T) {
	store := storage.NewMemory()
	storage.Seed(store, fixedNow)
	books := NewBookService(store, clock)

	result := books.Search(models.BookFilter{Author: "martin", Genre: "it"})
	if len(result) != 2 {
		t.Fatalf("ожидалось 2 книги Robert Martin в жанре IT, получено %d", len(result))
	}
	for _, b := range result {
		if b.Author != "Robert Martin" {
			t.Fatalf("в результат попала чужая книга: %+v", b)
		}
	}
	if result := books.Search(models.BookFilter{Year: 1949}); len(result) != 1 || result[0].Title != "1984" {
		t.Fatalf("фильтр по году работает неверно: %+v", result)
	}
	if _, err := ParseBookFilter("", "", "", "abc"); err == nil {
		t.Fatal("ожидалась ошибка для year=abc")
	}
}

func TestStatisticsComputedFromData(t *testing.T) {
	store := storage.NewMemory()
	storage.Seed(store, fixedNow)
	st := NewStatisticsService(store, clock).Get()

	if st.TotalBooks != 6 || st.TotalCopies != 15 {
		t.Fatalf("книги/экземпляры: %d/%d", st.TotalBooks, st.TotalCopies)
	}
	if st.ActiveLoans != 4 || st.AvailableCopies != 11 || st.BorrowedCopies != 4 {
		t.Fatalf("активные выдачи %d, доступно %d, выдано %d", st.ActiveLoans, st.AvailableCopies, st.BorrowedCopies)
	}
	if st.OverdueLoans != 1 {
		t.Fatalf("ожидалась 1 просроченная выдача, получено %d", st.OverdueLoans)
	}
	if st.TotalReaders != 4 || st.ActiveReaders != 3 {
		t.Fatalf("читатели %d, активные %d", st.TotalReaders, st.ActiveReaders)
	}
	if st.AvailabilityPercent != 73.33 {
		t.Fatalf("процент доступности %.2f", st.AvailabilityPercent)
	}
	if len(st.TopBooks) != 3 || st.TopBooks[0].BookID != 1 || st.TopBooks[0].LoanCount != 4 {
		t.Fatalf("топ книг: %+v", st.TopBooks)
	}
	total := 0
	for _, m := range st.LoansByMonth {
		total += m.Count
	}
	if len(st.LoansByMonth) != 12 || total != st.TotalLoans {
		t.Fatalf("выдачи по месяцам: %d месяцев, сумма %d, всего %d", len(st.LoansByMonth), total, st.TotalLoans)
	}
}

// Конкурентная выдача: 50 горутин пытаются взять книгу с 5 экземплярами — успешных выдач ровно 5.
func TestConcurrentIssueDoesNotOversell(t *testing.T) {
	store := storage.NewMemory()
	book, _ := NewBookService(store, clock).Create(models.BookInput{
		Title: strPtr("Go"), Author: strPtr("Donovan"), Year: intPtr(2015), Genre: strPtr("IT"), TotalCopies: intPtr(5),
	})
	readers := NewReaderService(store)
	loans := NewLoanService(store, clock)

	const attempts = 50
	readerIDs := make([]int, attempts)
	for i := range readerIDs {
		r, err := readers.Create(models.ReaderInput{
			FirstName: strPtr("R"), LastName: strPtr("R"), Email: strPtr("r" + itoa(i) + "@mail.kz"), Age: intPtr(20),
		})
		if err != nil {
			t.Fatalf("create reader: %v", err)
		}
		readerIDs[i] = r.ID
	}

	var wg sync.WaitGroup
	var mu sync.Mutex
	success := 0
	for i := 0; i < attempts; i++ {
		wg.Add(1)
		go func(readerID int) {
			defer wg.Done()
			if _, err := loans.Issue(models.LoanInput{BookID: &book.ID, ReaderID: &readerID}); err == nil {
				mu.Lock()
				success++
				mu.Unlock()
			}
		}(readerIDs[i])
	}
	wg.Wait()

	if success != 5 {
		t.Fatalf("ожидалось 5 успешных выдач, получено %d", success)
	}
	if got, _ := NewBookService(store, clock).Get(book.ID); got.AvailableCopies != 0 {
		t.Fatalf("ожидалось 0 доступных экземпляров, получено %d", got.AvailableCopies)
	}
}
