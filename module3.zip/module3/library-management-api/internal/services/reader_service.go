package services

import (
	"net/mail"
	"strconv"
	"strings"

	"library-management-api/internal/apperr"
	"library-management-api/internal/models"
	"library-management-api/internal/storage"
)

// ReaderService — операции с читателями.
type ReaderService struct {
	store *storage.Memory
}

// NewReaderService создаёт сервис читателей.
func NewReaderService(store *storage.Memory) *ReaderService {
	return &ReaderService{store: store}
}

// List возвращает читателей; если name не пустой — только тех, у кого имя или фамилия содержит name.
func (s *ReaderService) List(name string) []models.Reader {
	name = strings.TrimSpace(name)
	readers := make([]models.Reader, 0)
	s.store.Read(func(d *storage.Data) {
		for _, r := range d.Readers {
			if name == "" || containsFold(r.FullName(), name) {
				readers = append(readers, r)
			}
		}
	})
	sortReadersByID(readers)
	return readers
}

// Get возвращает читателя по ID.
func (s *ReaderService) Get(id int) (*models.Reader, error) {
	var reader *models.Reader
	var err error
	s.store.Read(func(d *storage.Data) {
		reader, err = findReader(d, id)
	})
	return reader, err
}

// Create регистрирует читателя; Email должен быть уникальным.
func (s *ReaderService) Create(in models.ReaderInput) (*models.Reader, error) {
	if err := validateReaderInput(in); err != nil {
		return nil, err
	}
	var created models.Reader
	err := s.store.Write(func(d *storage.Data) error {
		if emailTaken(d, *in.Email, 0) {
			return apperr.Conflict(apperr.CodeEmailExists, "Читатель с таким Email уже зарегистрирован")
		}
		created = models.Reader{ID: d.NextReaderID(), IsActive: true}
		applyReaderInput(&created, in)
		d.Readers[created.ID] = created
		return nil
	})
	return &created, err
}

// Update изменяет данные читателя; новый Email не должен принадлежать другому читателю.
func (s *ReaderService) Update(id int, in models.ReaderInput) (*models.Reader, error) {
	if err := validateReaderInput(in); err != nil {
		return nil, err
	}
	var updated *models.Reader
	err := s.store.Write(func(d *storage.Data) error {
		reader, err := findReader(d, id)
		if err != nil {
			return err
		}
		if emailTaken(d, *in.Email, id) {
			return apperr.Conflict(apperr.CodeEmailExists, "Читатель с таким Email уже зарегистрирован")
		}
		applyReaderInput(reader, in)
		d.Readers[id] = *reader
		updated = reader
		return nil
	})
	return updated, err
}

// Delete удаляет читателя, если у него нет активных выдач.
func (s *ReaderService) Delete(id int) error {
	return s.store.Write(func(d *storage.Data) error {
		if _, err := findReader(d, id); err != nil {
			return err
		}
		active := countActiveLoans(d, func(l models.Loan) bool { return l.ReaderID == id })
		if active > 0 {
			return apperr.Conflict(apperr.CodeReaderHasActiveLoans,
				"Нельзя удалить читателя: есть активные выдачи ("+strconv.Itoa(active)+")")
		}
		delete(d.Readers, id)
		return nil
	})
}

// Loans возвращает историю выдач читателя (активные и возвращённые).
func (s *ReaderService) Loans(id int) ([]models.Loan, error) {
	loans := make([]models.Loan, 0)
	var err error
	s.store.Read(func(d *storage.Data) {
		if _, err = findReader(d, id); err != nil {
			return
		}
		for _, l := range d.Loans {
			if l.ReaderID == id {
				loans = append(loans, l)
			}
		}
	})
	if err != nil {
		return nil, err
	}
	sortLoansByID(loans)
	return loans, nil
}

// emailTaken проверяет уникальность Email без учёта регистра, исключая читателя exceptID.
func emailTaken(d *storage.Data, email string, exceptID int) bool {
	email = normalizeEmail(email)
	for id, r := range d.Readers {
		if id != exceptID && normalizeEmail(r.Email) == email {
			return true
		}
	}
	return false
}

// normalizeEmail приводит Email к единому виду для сравнения.
func normalizeEmail(email string) string {
	return strings.ToLower(strings.TrimSpace(email))
}

// isValidEmail проверяет формат адреса: name@domain.zone без отображаемого имени.
func isValidEmail(email string) bool {
	addr, err := mail.ParseAddress(email)
	if err != nil || addr.Address != email {
		return false
	}
	at := strings.LastIndex(email, "@")
	return at > 0 && strings.Contains(email[at+1:], ".")
}

// validateReaderInput проверяет обязательные поля читателя.
func validateReaderInput(in models.ReaderInput) error {
	var problems []string
	problems = requireText(problems, "firstName", in.FirstName, MaxNameLength)
	problems = requireText(problems, "lastName", in.LastName, MaxNameLength)
	problems = requireText(problems, "email", in.Email, MaxTitleLength)
	if in.Email != nil && strings.TrimSpace(*in.Email) != "" && !isValidEmail(strings.TrimSpace(*in.Email)) {
		problems = append(problems, "email имеет некорректный формат")
	}
	problems = requireIntRange(problems, "age", in.Age, MinReaderAge, MaxReaderAge)
	return validationError(problems)
}

// applyReaderInput копирует поля запроса в читателя через указатель.
func applyReaderInput(r *models.Reader, in models.ReaderInput) {
	r.FirstName = strings.TrimSpace(*in.FirstName)
	r.LastName = strings.TrimSpace(*in.LastName)
	r.Email = strings.TrimSpace(*in.Email)
	r.Age = *in.Age
	if in.IsActive != nil {
		r.IsActive = *in.IsActive
	}
}

func itoa(n int) string {
	return strconv.Itoa(n)
}
