package services

import (
	"library-management-api/internal/apperr"
	"library-management-api/internal/models"
	"library-management-api/internal/storage"
)

// LoanService — выдача и возврат книг.
type LoanService struct {
	store *storage.Memory
	now   Clock
}

// NewLoanService создаёт сервис выдач.
func NewLoanService(store *storage.Memory, now Clock) *LoanService {
	return &LoanService{store: store, now: now}
}

// List возвращает все выдачи.
func (s *LoanService) List() []models.Loan {
	return s.filter(func(models.Loan) bool { return true })
}

// Active возвращает невозвращённые выдачи.
func (s *LoanService) Active() []models.Loan {
	return s.filter(models.Loan.IsActive)
}

// Get возвращает выдачу по ID.
func (s *LoanService) Get(id int) (*models.Loan, error) {
	var loan *models.Loan
	var err error
	s.store.Read(func(d *storage.Data) {
		loan, err = findLoan(d, id)
	})
	return loan, err
}

// Issue выдаёт книгу читателю. Все проверки и изменения выполняются под одной блокировкой.
func (s *LoanService) Issue(in models.LoanInput) (*models.Loan, error) {
	days, err := validateLoanInput(in)
	if err != nil {
		return nil, err
	}
	var created models.Loan
	err = s.store.Write(func(d *storage.Data) error {
		// Правило: нельзя выдать несуществующую книгу.
		book, err := findBook(d, *in.BookID)
		if err != nil {
			return err
		}
		// Правило: нельзя выдать книгу несуществующему или неактивному читателю.
		reader, err := findReader(d, *in.ReaderID)
		if err != nil {
			return err
		}
		if !reader.IsActive {
			return apperr.Conflict(apperr.CodeReaderInactive, "Читатель неактивен, выдача невозможна")
		}
		// Правило: не более MaxActiveLoansPerReader активных выдач у одного читателя.
		if countActiveLoans(d, func(l models.Loan) bool { return l.ReaderID == reader.ID }) >= MaxActiveLoansPerReader {
			return apperr.Conflict(apperr.CodeLoanLimitExceeded,
				"У читателя уже "+itoa(MaxActiveLoansPerReader)+" активных выдач — это максимум")
		}
		// Правило: нельзя выдать книгу, если AvailableCopies == 0; при выдаче остаток уменьшается на 1.
		if !book.TakeCopy() {
			return apperr.Conflict(apperr.CodeBookNotAvailable, "Нет доступных экземпляров книги")
		}
		now := s.now()
		created = models.Loan{
			ID:         d.NextLoanID(),
			BookID:     book.ID,
			ReaderID:   reader.ID,
			BorrowedAt: now,
			DueDate:    now.AddDate(0, 0, days),
		}
		d.Books[book.ID] = *book
		d.Loans[created.ID] = created
		return nil
	})
	if err != nil {
		return nil, err
	}
	return &created, nil
}

// Return оформляет возврат книги; повторный возврат запрещён.
func (s *LoanService) Return(id int) (*models.Loan, error) {
	var returned *models.Loan
	err := s.store.Write(func(d *storage.Data) error {
		loan, err := findLoan(d, id)
		if err != nil {
			return err
		}
		if loan.IsReturned {
			return apperr.Conflict(apperr.CodeLoanAlreadyReturned, "Книга по этой выдаче уже возвращена")
		}
		loan.MarkReturned(s.now())
		// При возврате количество доступных экземпляров увеличивается на 1.
		if book, err := findBook(d, loan.BookID); err == nil {
			book.ReturnCopy()
			d.Books[book.ID] = *book
		}
		d.Loans[loan.ID] = *loan
		returned = loan
		return nil
	})
	return returned, err
}

// filter возвращает выдачи, удовлетворяющие условию, упорядоченные по ID.
func (s *LoanService) filter(match func(models.Loan) bool) []models.Loan {
	loans := make([]models.Loan, 0)
	s.store.Read(func(d *storage.Data) {
		for _, l := range d.Loans {
			if match(l) {
				loans = append(loans, l)
			}
		}
	})
	sortLoansByID(loans)
	return loans
}

// validateLoanInput проверяет поля запроса и возвращает срок выдачи в днях (несколько возвращаемых значений).
func validateLoanInput(in models.LoanInput) (int, error) {
	var problems []string
	problems = requireIntRange(problems, "bookId", in.BookID, 1, 1<<31-1)
	problems = requireIntRange(problems, "readerId", in.ReaderID, 1, 1<<31-1)
	days := DefaultLoanDays
	if in.Days != nil {
		if *in.Days < 1 || *in.Days > MaxLoanDays {
			problems = append(problems, "days должно быть в диапазоне от 1 до "+itoa(MaxLoanDays))
		} else {
			days = *in.Days
		}
	}
	return days, validationError(problems)
}
