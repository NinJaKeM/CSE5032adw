// Library Management API — веб-сервис управления библиотекой (данные хранятся в памяти).
package main

import (
	"context"
	"errors"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"library-management-api/internal/router"
	"library-management-api/internal/storage"
)

// addr — сервер запускается на порту 8080.
const addr = ":8080"

func main() {
	log.SetFlags(log.Ldate | log.Ltime)

	store := storage.NewMemory()
	storage.Seed(store, time.Now())

	server := &http.Server{
		Addr:              addr,
		Handler:           router.New(store, time.Now),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      10 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go func() {
		log.Printf("INFO  Library Management API запущен на http://localhost%s", addr)
		if err := server.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
			log.Fatalf("ERROR сервер остановлен с ошибкой: %v", err)
		}
	}()

	<-ctx.Done()
	log.Printf("INFO  получен сигнал остановки, завершение работы...")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := server.Shutdown(shutdownCtx); err != nil {
		log.Printf("ERROR корректная остановка не удалась: %v", err)
	}
}
