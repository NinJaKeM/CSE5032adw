# Library Management API

Задание 3 (Модули 9–12), CSE5032 «Разработка веб-сервисов».

REST API на Go для управления библиотекой: книги, читатели, выдача и возврат книг, статистика.
Используется только стандартная библиотека Go (`net/http`, `encoding/json`, `sync`), без веб-фреймворков.
База данных не используется — данные хранятся в оперативной памяти в `map` и `slice`.

## Запуск

Требуется Go 1.22 или новее (маршруты вида `GET /api/books/{id}`).

```bash
go run ./cmd/server          # сервер на http://localhost:8080
go build ./...
go vet ./...
go test ./...
```

При запуске загружаются демонстрационные данные (`internal/storage/seed.go`): 6 книг, 4 читателя (один неактивный) и 10 выдач — 6 возвращённых и 4 активных, одна из них просрочена. Книга 6 («1984») имеет 1 экземпляр, и он выдан — на ней проверяется сценарий 9.

Сценарии тестирования (сервер должен быть запущен):

```powershell
powershell -ExecutionPolicy Bypass -File scripts\run-scenarios.ps1
```

Скрипт выполняет все 15 сценариев раздела 9 и дополнительные проверки, а запросы, ответы и итог PASS/FAIL сохраняет в [docs/scenarios.md](docs/scenarios.md).

## Результаты

- `go build ./...`, `go vet ./...`, `go test ./...` — завершаются с кодом 0, все 13 тестов проходят (`docs/screenshots/00_build_vet_test.png`).
- Все 15 сценариев раздела 9 и 6 дополнительных проверок (405, неизвестный маршрут, неактивный читатель, удаление книги с выдачей, нечисловой ID, шестая активная выдача) — PASS: [docs/scenarios.md](docs/scenarios.md), скриншоты `docs/screenshots/scenario_*.png`.
- Журнал HTTP-запросов сервера — `docs/screenshots/99_server_log.png`.

| № | Сценарий | Ожидается | Получено |
|---|---|---|---|
| 1 | Получение списка книг | 200 | 200 |
| 2 | Создание книги | 201 | 201 |
| 3 | Получение книги по ID | 200 | 200 |
| 4 | Обновление книги | 200 | 200 |
| 5 | Поиск книг по автору | 200 | 200 |
| 6 | Создание читателя | 201 | 201 |
| 7 | Повторная регистрация Email | 409 | 409 |
| 8 | Выдача доступной книги | 201 | 201 |
| 9 | Выдача книги без доступных экземпляров | 409 | 409 |
| 10 | Выдача книги несуществующему читателю | 404 | 404 |
| 11 | Возврат книги | 200 | 200 |
| 12 | Повторный возврат | 409 | 409 |
| 13 | История выдач читателя | 200 | 200 |
| 14 | Статистика | 200 | 200 |
| 15 | Некорректный JSON / нет обязательных полей | 400 | 400 |

## Архитектура

```
HTTP-клиент (Postman / curl)
   │  JSON
   ▼
middleware.Logging  →  middleware.Recovery  →  обработка 404 / 405  →  http.ServeMux (router)
   ▼
handlers   разбор JSON, path- и query-параметров; ответ в едином формате (response)
   ▼
services   валидация, поиск, расчёты, бизнес-правила
   ▼
storage    map[int]Book, map[int]Reader, map[int]Loan под sync.RWMutex
```

```
library-management-api/
├── cmd/server/main.go            запуск HTTP-сервера на :8080, корректная остановка
├── internal/
│   ├── models/                   book.go, reader.go, loan.go — структуры и методы моделей
│   ├── handlers/                 book_handler.go, reader_handler.go, loan_handler.go, common.go
│   ├── services/                 book_service.go, reader_service.go, loan_service.go,
│   │                             statistics_service.go, common.go, services_test.go
│   ├── storage/                  memory.go (хранилище + RWMutex), seed.go (демо-данные)
│   ├── middleware/logging.go     логирование запросов, recovery
│   ├── response/response.go      единый формат ответа
│   ├── apperr/apperr.go          ошибки приложения: HTTP-статус + код
│   └── router/                   router.go (маршруты), router_test.go (httptest)
├── scripts/run-scenarios.ps1     выполнение сценариев тестирования
├── docs/scenarios.md             результаты сценариев
├── docs/screenshots/             скриншоты: build/vet/test, 15 сценариев, журнал сервера
├── go.mod
└── README.md
```

Обработчики не содержат бизнес-логики, сервисы не знают про HTTP, хранилище не знает про бизнес-правила.

## Endpoints (19)

| Метод | Endpoint | Описание | Успех | Ошибки |
|---|---|---|---|---|
| GET | `/api/books` | Все книги | 200 | |
| GET | `/api/books/{id}` | Книга по ID | 200 | 400, 404 |
| POST | `/api/books` | Добавить книгу | 201 | 400 |
| PUT | `/api/books/{id}` | Обновить книгу | 200 | 400, 404, 409 |
| DELETE | `/api/books/{id}` | Удалить книгу | 200 | 400, 404, 409 |
| GET | `/api/books/search` | Фильтр: `title`, `author`, `genre`, `year` | 200 | 400 |
| GET | `/api/readers` | Все читатели; поиск по имени `?name=` | 200 | |
| GET | `/api/readers/{id}` | Читатель по ID | 200 | 400, 404 |
| POST | `/api/readers` | Зарегистрировать читателя | 201 | 400, 409 |
| PUT | `/api/readers/{id}` | Обновить данные | 200 | 400, 404, 409 |
| DELETE | `/api/readers/{id}` | Удалить читателя | 200 | 400, 404, 409 |
| GET | `/api/readers/{id}/loans` | История выдач читателя | 200 | 400, 404 |
| GET | `/api/loans` | Все выдачи | 200 | |
| GET | `/api/loans/{id}` | Выдача по ID | 200 | 400, 404 |
| POST | `/api/loans` | Выдать книгу | 201 | 400, 404, 409 |
| PUT | `/api/loans/{id}/return` | Вернуть книгу | 200 | 400, 404, 409 |
| GET | `/api/loans/active` | Активные выдачи | 200 | |
| GET | `/api/statistics` | Статистика библиотеки | 200 | |

Для любого другого пути — `404 ROUTE_NOT_FOUND`, для существующего пути с другим методом — `405 METHOD_NOT_ALLOWED` с заголовком `Allow`. Непредвиденная ошибка (паника) — `500 INTERNAL_SERVER_ERROR` без технических деталей.

## Единый формат ответа

```json
{
  "statusCode": 409,
  "isSuccess": false,
  "result": null,
  "errorCode": "BOOK_NOT_AVAILABLE",
  "errorMessage": "Нет доступных экземпляров книги"
}
```

| HTTP | errorCode | Когда |
|---|---|---|
| 400 | `INVALID_JSON` | пустое тело, синтаксическая ошибка, неверный тип или неизвестное поле, лишние данные |
| 400 | `VALIDATION_ERROR` | отсутствуют обязательные поля, значения вне диапазона, неверный Email |
| 400 | `INVALID_ID`, `INVALID_QUERY` | нечисловой `{id}`, нечисловой `year` |
| 404 | `BOOK_NOT_FOUND`, `READER_NOT_FOUND`, `LOAN_NOT_FOUND`, `ROUTE_NOT_FOUND` | ресурс или маршрут не существует |
| 405 | `METHOD_NOT_ALLOWED` | неподдерживаемый HTTP-метод |
| 409 | `EMAIL_ALREADY_EXISTS` | Email уже зарегистрирован (без учёта регистра) |
| 409 | `BOOK_NOT_AVAILABLE` | `AvailableCopies == 0` |
| 409 | `READER_INACTIVE` | читатель неактивен |
| 409 | `LOAN_LIMIT_EXCEEDED` | у читателя уже 5 активных выдач |
| 409 | `LOAN_ALREADY_RETURNED` | повторный возврат |
| 409 | `BOOK_HAS_ACTIVE_LOANS`, `READER_HAS_ACTIVE_LOANS` | удаление при активных выдачах |
| 409 | `COPIES_LESS_THAN_BORROWED` | `totalCopies` меньше числа выданных экземпляров |
| 500 | `INTERNAL_SERVER_ERROR` | непредвиденная ошибка |

## Бизнес-правила выдачи

Реализованы в `LoanService.Issue` и `LoanService.Return` (`internal/services/loan_service.go`):

1. Нельзя выдать несуществующую книгу — 404 `BOOK_NOT_FOUND`.
2. Нельзя выдать книгу несуществующему (404 `READER_NOT_FOUND`) или неактивному (409 `READER_INACTIVE`) читателю.
3. Нельзя выдать книгу, если `AvailableCopies == 0` — 409 `BOOK_NOT_AVAILABLE`.
4. При выдаче `AvailableCopies` уменьшается на 1 (`(*Book).TakeCopy`).
5. При возврате `AvailableCopies` увеличивается на 1 (`(*Book).ReturnCopy`).
6. Нельзя повторно вернуть книгу — 409 `LOAN_ALREADY_RETURNED`.
7. Не более `MaxActiveLoansPerReader = 5` активных выдач у читателя — 409 `LOAN_LIMIT_EXCEEDED`.
8. Нельзя удалить книгу или читателя с активными выдачами — 409 `BOOK_HAS_ACTIVE_LOANS` / `READER_HAS_ACTIVE_LOANS`.

Срок выдачи — поле `days` (1–60, по умолчанию 14), `DueDate = BorrowedAt + days`.

## Примеры запросов и ответов

**POST /api/books** → 201

```json
{ "title": "Go in Action", "author": "William Kennedy", "year": 2015, "genre": "IT", "totalCopies": 2 }
```

```json
{
  "statusCode": 201,
  "isSuccess": true,
  "result": { "id": 7, "title": "Go in Action", "author": "William Kennedy", "year": 2015, "genre": "IT", "totalCopies": 2, "availableCopies": 2 },
  "errorCode": null,
  "errorMessage": null
}
```

**POST /api/readers** → 201

```json
{ "firstName": "Дана", "lastName": "Омарова", "email": "dana.omarova@mail.kz", "age": 20 }
```

`isActive` необязательно: при регистрации по умолчанию `true`.

**POST /api/loans** → 201

```json
{ "bookId": 7, "readerId": 5, "days": 14 }
```

```json
{
  "statusCode": 201,
  "isSuccess": true,
  "result": { "id": 11, "bookId": 7, "readerId": 5, "borrowedAt": "2026-11-22T10:00:00Z", "dueDate": "2026-12-06T10:00:00Z", "returnedAt": null, "isReturned": false },
  "errorCode": null,
  "errorMessage": null
}
```

**POST /api/books** с пропущенными полями → 400

```json
{
  "statusCode": 400,
  "isSuccess": false,
  "result": null,
  "errorCode": "VALIDATION_ERROR",
  "errorMessage": "Некорректные данные: author — обязательное поле; genre — обязательное поле; year — обязательное поле; totalCopies — обязательное поле"
}
```

**GET /api/statistics** → 200 (фрагмент)

```json
{
  "totalBooks": 6, "totalCopies": 15, "availableCopies": 11, "borrowedCopies": 4,
  "availabilityPercent": 73.33,
  "totalReaders": 4, "activeReaders": 3,
  "totalLoans": 10, "activeLoans": 4, "overdueLoans": 1,
  "topBooks": [ { "bookId": 1, "title": "Clean Code", "author": "Robert Martin", "loanCount": 4 }, "..." ],
  "loansByMonth": [ { "month": 1, "name": "Январь", "count": 0 }, "..." ]
}
```

Все значения статистики вычисляются по текущим данным при каждом запросе.

## Где используются конструкции Go

| Тема | Где в проекте |
|---|---|
| Базовые типы `int`, `string`, `bool`, `float64` | модели (`internal/models`); `float64` — `availabilityPercent` в `statistics_service.go` |
| `if` / `else` / `switch` | валидация (`requireText` — `switch`), `decodeJSON` — `switch` по типу ошибки, уровень лога в `middleware.Logging` |
| Циклы `for` | поиск (`BookService.Search`, `ReaderService.List`), подсчёт активных выдач (`countActiveLoans`), статистика, `emailTaken` |
| Операторы сравнения, логические, арифметические | фильтр `matchesBookFilter`, процент доступности, `BorrowedCopies`, проверка `IsOverdue` |
| `struct` | `Book`, `Reader`, `Loan`, `BookInput`, `Statistics`, `APIResponse`, `storage.Data` |
| `const` | `MaxActiveLoansPerReader = 5`, `DefaultLoanDays`, `MaxLoanDays`, диапазоны валидации, коды ошибок, `addr = ":8080"` |
| `map[int]Book`, `map[int]Reader`, `map[int]Loan` | основное хранилище `storage.Data`; `map[int]int` — подсчёт выдач по книгам в `topBooks` |
| `[]Book` и другие срезы | результаты `List`, `Search`, `Active`, история выдач, топ книг |
| `[12]int` | `loansByMonth` — выдачи по месяцам; `[12]string` — названия месяцев; `[][5]int` — история в `seed.go` |
| Функции (не обработчики) | `findBook`, `findReader`, `findLoan`, `countActiveLoans`, `containsFold`, `matchesBookFilter`, `applyBookInput`, `applyReaderInput`, `validateReaderInput`, `validateLoanInput`, `isValidEmail`, `normalizeEmail`, `emailTaken`, `ParseBookFilter`, `requireText`, `requireIntRange`, `availabilityPercent`, `loansByMonth`, `monthStats`, `topBooks`, `sortBooksByID` и др. — больше 20 |
| Указатели | `findBook` возвращает `*models.Book`, изменение через `(*Book).TakeCopy`, `(*Book).ReturnCopy`, `(*Loan).MarkReturned`, `applyBookInput(b *Book, …)`; поля `*string`/`*int` в `*Input` отличают отсутствующее поле от нуля; `ReturnedAt *time.Time` |
| Несколько возвращаемых значений | `findBook(d, id) (*Book, error)`, `BookService.Get`, `validateLoanInput(in) (int, error)`, `ParseBookFilter(...) (BookFilter, error)` |
| `error` | пакет `apperr` (тип `*apperr.Error` со статусом и кодом), `errors.As` в `response.Error` |
| HTTP-сервер, JSON | `cmd/server/main.go` (`http.Server` на `:8080`), `encoding/json` в `handlers/common.go` и `response/response.go` |
| Маршрутизация | `router/router.go`: `http.ServeMux`, шаблоны `"GET /api/books/{id}"`, `r.PathValue("id")`, query `r.URL.Query()`; разные методы одного ресурса |
| Middleware | `middleware.Logging` (метод, путь, статус, размер, время), `middleware.Recovery` (паника → 500), JSON-обработка 404/405 |
| Конкурентность | `storage.Memory`: `sync.RWMutex`; чтение — `Read` (RLock), изменение — `Write` (Lock): проверка правил и изменение данных выполняются атомарно |

## Тесты

`go test ./...` — 13 тестов:

- `internal/services/services_test.go` (unit): выдача и возврат меняют `AvailableCopies`, повторный возврат — 409; все бизнес-правила выдачи; лимит 5 активных выдач; запрет удаления при активных выдачах; уникальность Email; фильтр книг; расчёт статистики; конкурентная выдача — 50 горутин и 5 экземпляров дают ровно 5 выдач;
- `internal/router/router_test.go` (HTTP через `net/http/httptest`): `GET /api/books` — 200; создание книги — 201 и пять вариантов некорректных данных — 400; цепочка выдачи 409 → 404 → 201 → 200 → 409; маршрутизация 404 / 405 / неверный ID / поиск; Recovery middleware — 500 без технических деталей.
