# Результаты выполнения сценариев тестирования

Дата: 2026-11-24 00:24, сервер: http://localhost:8080

| № | Сценарий | Ожидается | Получено | Итог |
|---|---|---|---|---|
| 1 | Получение списка книг | 200 | 200 | PASS |
| 2 | Создание книги | 201 | 201 | PASS |
| 3 | Получение книги по ID | 200 | 200 | PASS |
| 4 | Обновление книги | 200 | 200 | PASS |
| 5 | Поиск книг по автору (author=Martin&genre=IT) | 200 | 200 | PASS |
| 6 | Создание читателя | 201 | 201 | PASS |
| 7 | Повторная регистрация Email | 409 | 409 | PASS |
| 8 | Выдача доступной книги | 201 | 201 | PASS |
| 9 | Выдача книги без доступных экземпляров (книга 6 «1984») | 409 | 409 | PASS |
| 10 | Выдача книги несуществующему читателю | 404 | 404 | PASS |
| 11 | Возврат книги | 200 | 200 | PASS |
| 12 | Повторный возврат | 409 | 409 | PASS |
| 13 | Получение истории выдач читателя | 200 | 200 | PASS |
| 14 | Получение статистики | 200 | 200 | PASS |
| 15a | Некорректный JSON | 400 | 400 | PASS |
| 15b | Отсутствуют обязательные поля | 400 | 400 | PASS |
| D1 | Неподдерживаемый HTTP-метод (PATCH /api/books/1) | 405 | 405 | PASS |
| D2 | Неизвестный маршрут | 404 | 404 | PASS |
| D3 | Выдача неактивному читателю (читатель 4) | 409 | 409 | PASS |
| D4 | Удаление книги с активной выдачей (книга 1) | 409 | 409 | PASS |
| D5 | Нечисловой ID | 400 | 400 | PASS |
| D6 | Шестая активная выдача одному читателю | 409 | 409 | PASS |

---

## 1. Получение списка книг

**Запрос:** `GET /api/books`  
**Ожидается:** 200 · **Получено:** 200 · **PASS**

Ответ:

```json
{
  "statusCode": 200,
  "isSuccess": true,
  "result": [
    {
      "id": 1,
      "title": "Clean Code",
      "author": "Robert Martin",
      "year": 2008,
      "genre": "IT",
      "totalCopies": 3,
      "availableCopies": 2
    },
    {
      "id": 2,
      "title": "Clean Architecture",
      "author": "Robert Martin",
      "year": 2017,
      "genre": "IT",
      "totalCopies": 2,
      "availableCopies": 1
    },
    {
      "id": 3,
      "title": "The Go Programming Language",
      "author": "Alan Donovan",
      "year": 2015,
      "genre": "IT",
      "totalCopies": 4,
      "availableCopies": 4
    },
    {
      "id": 4,
      "title": "Путь Абая",
      "author": "Мухтар Ауэзов",
      "year": 1942,
      "genre": "Роман",
      "totalCopies": 3,
      "availableCopies": 2
    },
    {
      "id": 5,
      "title": "Мастер и Маргарита",
      "author": "Михаил Булгаков",
      "year": 1967,
      "genre": "Роман",
      "totalCopies": 2,
      "availableCopies": 2
    },
    {
      "id": 6,
      "title": "1984",
      "author": "George Orwell",
      "year": 1949,
      "genre": "Антиутопия",
      "totalCopies": 1,
      "availableCopies": 0
    }
  ],
  "errorCode": null,
  "errorMessage": null
}
```

## 2. Создание книги

**Запрос:** `POST /api/books`  
**Ожидается:** 201 · **Получено:** 201 · **PASS**

```json
{"title":"Go in Action","author":"William Kennedy","year":2015,"genre":"IT","totalCopies":2}
```

Ответ:

```json
{
  "statusCode": 201,
  "isSuccess": true,
  "result": {
    "id": 7,
    "title": "Go in Action",
    "author": "William Kennedy",
    "year": 2015,
    "genre": "IT",
    "totalCopies": 2,
    "availableCopies": 2
  },
  "errorCode": null,
  "errorMessage": null
}
```

## 3. Получение книги по ID

**Запрос:** `GET /api/books/7`  
**Ожидается:** 200 · **Получено:** 200 · **PASS**

Ответ:

```json
{
  "statusCode": 200,
  "isSuccess": true,
  "result": {
    "id": 7,
    "title": "Go in Action",
    "author": "William Kennedy",
    "year": 2015,
    "genre": "IT",
    "totalCopies": 2,
    "availableCopies": 2
  },
  "errorCode": null,
  "errorMessage": null
}
```

## 4. Обновление книги

**Запрос:** `PUT /api/books/7`  
**Ожидается:** 200 · **Получено:** 200 · **PASS**

```json
{"title":"Go in Action (2nd ed.)","author":"William Kennedy","year":2016,"genre":"IT","totalCopies":3}
```

Ответ:

```json
{
  "statusCode": 200,
  "isSuccess": true,
  "result": {
    "id": 7,
    "title": "Go in Action (2nd ed.)",
    "author": "William Kennedy",
    "year": 2016,
    "genre": "IT",
    "totalCopies": 3,
    "availableCopies": 3
  },
  "errorCode": null,
  "errorMessage": null
}
```

## 5. Поиск книг по автору (author=Martin&genre=IT)

**Запрос:** `GET /api/books/search?author=Martin&genre=IT`  
**Ожидается:** 200 · **Получено:** 200 · **PASS**

Ответ:

```json
{
  "statusCode": 200,
  "isSuccess": true,
  "result": [
    {
      "id": 1,
      "title": "Clean Code",
      "author": "Robert Martin",
      "year": 2008,
      "genre": "IT",
      "totalCopies": 3,
      "availableCopies": 2
    },
    {
      "id": 2,
      "title": "Clean Architecture",
      "author": "Robert Martin",
      "year": 2017,
      "genre": "IT",
      "totalCopies": 2,
      "availableCopies": 1
    }
  ],
  "errorCode": null,
  "errorMessage": null
}
```

## 6. Создание читателя

**Запрос:** `POST /api/readers`  
**Ожидается:** 201 · **Получено:** 201 · **PASS**

```json
{"firstName":"Дана","lastName":"Омарова","email":"dana.omarova@mail.kz","age":20}
```

Ответ:

```json
{
  "statusCode": 201,
  "isSuccess": true,
  "result": {
    "id": 5,
    "firstName": "Дана",
    "lastName": "Омарова",
    "email": "dana.omarova@mail.kz",
    "age": 20,
    "isActive": true
  },
  "errorCode": null,
  "errorMessage": null
}
```

## 7. Повторная регистрация Email

**Запрос:** `POST /api/readers`  
**Ожидается:** 409 · **Получено:** 409 · **PASS**

```json
{"firstName":"Дана","lastName":"Омарова","email":"DANA.OMAROVA@mail.kz","age":20}
```

Ответ:

```json
{
  "statusCode": 409,
  "isSuccess": false,
  "result": null,
  "errorCode": "EMAIL_ALREADY_EXISTS",
  "errorMessage": "Читатель с таким Email уже зарегистрирован"
}
```

## 8. Выдача доступной книги

**Запрос:** `POST /api/loans`  
**Ожидается:** 201 · **Получено:** 201 · **PASS**

```json
{"bookId":7,"readerId":5}
```

Ответ:

```json
{
  "statusCode": 201,
  "isSuccess": true,
  "result": {
    "id": 11,
    "bookId": 7,
    "readerId": 5,
    "borrowedAt": "2026-11-24T00:24:38.7825572+05:00",
    "dueDate": "2026-12-08T00:24:38.7825572+05:00",
    "returnedAt": null,
    "isReturned": false
  },
  "errorCode": null,
  "errorMessage": null
}
```

## 9. Выдача книги без доступных экземпляров (книга 6 «1984»)

**Запрос:** `POST /api/loans`  
**Ожидается:** 409 · **Получено:** 409 · **PASS**

```json
{"bookId":6,"readerId":5}
```

Ответ:

```json
{
  "statusCode": 409,
  "isSuccess": false,
  "result": null,
  "errorCode": "BOOK_NOT_AVAILABLE",
  "errorMessage": "Нет доступных экземпляров книги"
}
```

## 10. Выдача книги несуществующему читателю

**Запрос:** `POST /api/loans`  
**Ожидается:** 404 · **Получено:** 404 · **PASS**

```json
{"bookId":7,"readerId":999}
```

Ответ:

```json
{
  "statusCode": 404,
  "isSuccess": false,
  "result": null,
  "errorCode": "READER_NOT_FOUND",
  "errorMessage": "Читатель не найден"
}
```

## 11. Возврат книги

**Запрос:** `PUT /api/loans/11/return`  
**Ожидается:** 200 · **Получено:** 200 · **PASS**

Ответ:

```json
{
  "statusCode": 200,
  "isSuccess": true,
  "result": {
    "id": 11,
    "bookId": 7,
    "readerId": 5,
    "borrowedAt": "2026-11-24T00:24:38.7825572+05:00",
    "dueDate": "2026-12-08T00:24:38.7825572+05:00",
    "returnedAt": "2026-11-24T00:24:38.7899559+05:00",
    "isReturned": true
  },
  "errorCode": null,
  "errorMessage": null
}
```

## 12. Повторный возврат

**Запрос:** `PUT /api/loans/11/return`  
**Ожидается:** 409 · **Получено:** 409 · **PASS**

Ответ:

```json
{
  "statusCode": 409,
  "isSuccess": false,
  "result": null,
  "errorCode": "LOAN_ALREADY_RETURNED",
  "errorMessage": "Книга по этой выдаче уже возвращена"
}
```

## 13. Получение истории выдач читателя

**Запрос:** `GET /api/readers/5/loans`  
**Ожидается:** 200 · **Получено:** 200 · **PASS**

Ответ:

```json
{
  "statusCode": 200,
  "isSuccess": true,
  "result": [
    {
      "id": 11,
      "bookId": 7,
      "readerId": 5,
      "borrowedAt": "2026-11-24T00:24:38.7825572+05:00",
      "dueDate": "2026-12-08T00:24:38.7825572+05:00",
      "returnedAt": "2026-11-24T00:24:38.7899559+05:00",
      "isReturned": true
    }
  ],
  "errorCode": null,
  "errorMessage": null
}
```

## 14. Получение статистики

**Запрос:** `GET /api/statistics`  
**Ожидается:** 200 · **Получено:** 200 · **PASS**

Ответ:

```json
{
  "statusCode": 200,
  "isSuccess": true,
  "result": {
    "totalBooks": 7,
    "totalCopies": 18,
    "availableCopies": 14,
    "borrowedCopies": 4,
    "availabilityPercent": 77.78,
    "totalReaders": 5,
    "activeReaders": 4,
    "totalLoans": 11,
    "activeLoans": 4,
    "overdueLoans": 1,
    "topBooks": [
      {
        "bookId": 1,
        "title": "Clean Code",
        "author": "Robert Martin",
        "loanCount": 4
      },
      {
        "bookId": 3,
        "title": "The Go Programming Language",
        "author": "Alan Donovan",
        "loanCount": 2
      },
      {
        "bookId": 2,
        "title": "Clean Architecture",
        "author": "Robert Martin",
        "loanCount": 1
      }
    ],
    "loansByMonth": [
      {
        "month": 1,
        "name": "Январь",
        "count": 0
      },
      {
        "month": 2,
        "name": "Февраль",
        "count": 0
      },
      {
        "month": 3,
        "name": "Март",
        "count": 0
      },
      {
        "month": 4,
        "name": "Апрель",
        "count": 0
      },
      {
        "month": 5,
        "name": "Май",
        "count": 0
      },
      {
        "month": 6,
        "name": "Июнь",
        "count": 1
      },
      {
        "month": 7,
        "name": "Июль",
        "count": 1
      },
      {
        "month": 8,
        "name": "Август",
        "count": 1
      },
      {
        "month": 9,
        "name": "Сентябрь",
        "count": 1
      },
      {
        "month": 10,
        "name": "Октябрь",
        "count": 2
      },
      {
        "month": 11,
        "name": "Ноябрь",
        "count": 5
      },
      {
        "month": 12,
        "name": "Декабрь",
        "count": 0
      }
    ]
  },
  "errorCode": null,
  "errorMessage": null
}
```

## 15a. Некорректный JSON

**Запрос:** `POST /api/books`  
**Ожидается:** 400 · **Получено:** 400 · **PASS**

```json
{"title": "Broken"
```

Ответ:

```json
{
  "statusCode": 400,
  "isSuccess": false,
  "result": null,
  "errorCode": "INVALID_JSON",
  "errorMessage": "Некорректный JSON"
}
```

## 15b. Отсутствуют обязательные поля

**Запрос:** `POST /api/readers`  
**Ожидается:** 400 · **Получено:** 400 · **PASS**

```json
{"firstName":"Без","email":"not-an-email"}
```

Ответ:

```json
{
  "statusCode": 400,
  "isSuccess": false,
  "result": null,
  "errorCode": "VALIDATION_ERROR",
  "errorMessage": "Некорректные данные: lastName — обязательное поле; email имеет некорректный формат; age — обязательное поле"
}
```

## D1. Неподдерживаемый HTTP-метод (PATCH /api/books/1)

**Запрос:** `PATCH /api/books/1`  
**Ожидается:** 405 · **Получено:** 405 · **PASS**

Ответ:

```json
{
  "statusCode": 405,
  "isSuccess": false,
  "result": null,
  "errorCode": "METHOD_NOT_ALLOWED",
  "errorMessage": "Метод PATCH не поддерживается для /api/books/1. Разрешены: GET, PUT, DELETE"
}
```

## D2. Неизвестный маршрут

**Запрос:** `GET /api/authors`  
**Ожидается:** 404 · **Получено:** 404 · **PASS**

Ответ:

```json
{
  "statusCode": 404,
  "isSuccess": false,
  "result": null,
  "errorCode": "ROUTE_NOT_FOUND",
  "errorMessage": "Маршрут /api/authors не найден"
}
```

## D3. Выдача неактивному читателю (читатель 4)

**Запрос:** `POST /api/loans`  
**Ожидается:** 409 · **Получено:** 409 · **PASS**

```json
{"bookId":3,"readerId":4}
```

Ответ:

```json
{
  "statusCode": 409,
  "isSuccess": false,
  "result": null,
  "errorCode": "READER_INACTIVE",
  "errorMessage": "Читатель неактивен, выдача невозможна"
}
```

## D4. Удаление книги с активной выдачей (книга 1)

**Запрос:** `DELETE /api/books/1`  
**Ожидается:** 409 · **Получено:** 409 · **PASS**

Ответ:

```json
{
  "statusCode": 409,
  "isSuccess": false,
  "result": null,
  "errorCode": "BOOK_HAS_ACTIVE_LOANS",
  "errorMessage": "Нельзя удалить книгу: есть активные выдачи (1)"
}
```

## D5. Нечисловой ID

**Запрос:** `GET /api/books/abc`  
**Ожидается:** 400 · **Получено:** 400 · **PASS**

Ответ:

```json
{
  "statusCode": 400,
  "isSuccess": false,
  "result": null,
  "errorCode": "INVALID_ID",
  "errorMessage": "Идентификатор должен быть положительным целым числом"
}
```

## D6. Шестая активная выдача одному читателю

**Запрос:** `POST /api/loans`  
**Ожидается:** 409 · **Получено:** 409 · **PASS**

```json
{"bookId":5,"readerId":5}
```

Ответ:

```json
{
  "statusCode": 409,
  "isSuccess": false,
  "result": null,
  "errorCode": "LOAN_LIMIT_EXCEEDED",
  "errorMessage": "У читателя уже 5 активных выдач — это максимум"
}
```

