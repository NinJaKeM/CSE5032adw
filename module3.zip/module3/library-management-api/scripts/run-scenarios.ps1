﻿# Выполняет 15 сценариев тестирования из раздела 9 ТЗ (и дополнительные проверки) и сохраняет
# запросы и ответы в docs/scenarios.md. Сервер должен быть запущен: go run ./cmd/server
# Запуск: powershell -ExecutionPolicy Bypass -File scripts\run-scenarios.ps1
param([string]$BaseUrl = 'http://localhost:8080')

$ErrorActionPreference = 'Stop'
$out = Join-Path $PSScriptRoot '..\docs\scenarios.md'
$utf8 = New-Object System.Text.UTF8Encoding $false
$lines = New-Object System.Collections.Generic.List[string]
$summary = New-Object System.Collections.Generic.List[string]

function Invoke-Api([string]$Method, [string]$Path, [string]$Body) {
    $req = [System.Net.HttpWebRequest]::Create($BaseUrl + $Path)
    $req.Method = $Method
    if ($Body -ne $null -and $Body -ne '') {
        $bytes = $utf8.GetBytes($Body)
        $req.ContentType = 'application/json; charset=utf-8'
        $req.ContentLength = $bytes.Length
        $s = $req.GetRequestStream(); $s.Write($bytes, 0, $bytes.Length); $s.Close()
    } elseif ($Method -in 'POST', 'PUT') {
        $req.ContentLength = 0
    }
    try { $resp = $req.GetResponse() } catch [System.Net.WebException] { $resp = $_.Exception.Response }
    $reader = New-Object System.IO.StreamReader($resp.GetResponseStream(), $utf8)
    $text = $reader.ReadToEnd(); $reader.Close()
    $status = [int]$resp.StatusCode; $resp.Close()
    return @{ Status = $status; Body = $text }
}

function Step([string]$No, [string]$Title, [int]$Expected, [string]$Method, [string]$Path, [string]$Body = '') {
    $r = Invoke-Api $Method $Path $Body
    $ok = if ($r.Status -eq $Expected) { 'PASS' } else { 'FAIL' }
    $summary.Add("| $No | $Title | $Expected | $($r.Status) | $ok |")
    $lines.Add("## $No. $Title")
    $lines.Add('')
    $lines.Add("**Запрос:** ``$Method $Path``  ")
    $lines.Add("**Ожидается:** $Expected · **Получено:** $($r.Status) · **$ok**")
    if ($Body) { $lines.Add(''); $lines.Add('```json'); $lines.Add($Body); $lines.Add('```') }
    $lines.Add(''); $lines.Add('Ответ:'); $lines.Add(''); $lines.Add('```json'); $lines.Add($r.Body.TrimEnd()); $lines.Add('```'); $lines.Add('')
    Write-Host ("{0,-4} {1,-55} expected {2} got {3} {4}" -f $No, $Title, $Expected, $r.Status, $ok)
    return $r
}

Step '1' 'Получение списка книг' 200 'GET' '/api/books' | Out-Null
$created = Step '2' 'Создание книги' 201 'POST' '/api/books' '{"title":"Go in Action","author":"William Kennedy","year":2015,"genre":"IT","totalCopies":2}'
$bookId = ($created.Body | ConvertFrom-Json).result.id
Step '3' 'Получение книги по ID' 200 'GET' "/api/books/$bookId" | Out-Null
Step '4' 'Обновление книги' 200 'PUT' "/api/books/$bookId" '{"title":"Go in Action (2nd ed.)","author":"William Kennedy","year":2016,"genre":"IT","totalCopies":3}' | Out-Null
Step '5' 'Поиск книг по автору (author=Martin&genre=IT)' 200 'GET' '/api/books/search?author=Martin&genre=IT' | Out-Null
$reader = Step '6' 'Создание читателя' 201 'POST' '/api/readers' '{"firstName":"Дана","lastName":"Омарова","email":"dana.omarova@mail.kz","age":20}'
$readerId = ($reader.Body | ConvertFrom-Json).result.id
Step '7' 'Повторная регистрация Email' 409 'POST' '/api/readers' '{"firstName":"Дана","lastName":"Омарова","email":"DANA.OMAROVA@mail.kz","age":20}' | Out-Null
$loan = Step '8' 'Выдача доступной книги' 201 'POST' '/api/loans' ('{"bookId":' + $bookId + ',"readerId":' + $readerId + '}')
$loanId = ($loan.Body | ConvertFrom-Json).result.id
Step '9' 'Выдача книги без доступных экземпляров (книга 6 «1984»)' 409 'POST' '/api/loans' ('{"bookId":6,"readerId":' + $readerId + '}') | Out-Null
Step '10' 'Выдача книги несуществующему читателю' 404 'POST' '/api/loans' ('{"bookId":' + $bookId + ',"readerId":999}') | Out-Null
Step '11' 'Возврат книги' 200 'PUT' "/api/loans/$loanId/return" | Out-Null
Step '12' 'Повторный возврат' 409 'PUT' "/api/loans/$loanId/return" | Out-Null
Step '13' 'Получение истории выдач читателя' 200 'GET' "/api/readers/$readerId/loans" | Out-Null
Step '14' 'Получение статистики' 200 'GET' '/api/statistics' | Out-Null
Step '15a' 'Некорректный JSON' 400 'POST' '/api/books' '{"title": "Broken"' | Out-Null
Step '15b' 'Отсутствуют обязательные поля' 400 'POST' '/api/readers' '{"firstName":"Без","email":"not-an-email"}' | Out-Null

# Дополнительные проверки (раздел 9: ограничения, маршрутизация)
Step 'D1' 'Неподдерживаемый HTTP-метод (PATCH /api/books/1)' 405 'PATCH' '/api/books/1' | Out-Null
Step 'D2' 'Неизвестный маршрут' 404 'GET' '/api/authors' | Out-Null
Step 'D3' 'Выдача неактивному читателю (читатель 4)' 409 'POST' '/api/loans' '{"bookId":3,"readerId":4}' | Out-Null
Step 'D4' 'Удаление книги с активной выдачей (книга 1)' 409 'DELETE' '/api/books/1' | Out-Null
Step 'D5' 'Нечисловой ID' 400 'GET' '/api/books/abc' | Out-Null
# 5 активных выдач читателю: 3 экземпляра созданной книги и 2 экземпляра книги 3
foreach ($b in @($bookId, $bookId, $bookId, 3, 3)) { Invoke-Api 'POST' '/api/loans' ('{"bookId":' + $b + ',"readerId":' + $readerId + '}') | Out-Null }
Step 'D6' 'Шестая активная выдача одному читателю' 409 'POST' '/api/loans' ('{"bookId":5,"readerId":' + $readerId + '}') | Out-Null

$header = @(
    '# Результаты выполнения сценариев тестирования',
    '',
    "Дата: $(Get-Date -Format 'yyyy-MM-dd HH:mm'), сервер: $BaseUrl",
    '',
    '| № | Сценарий | Ожидается | Получено | Итог |',
    '|---|---|---|---|---|'
) + $summary + @('', '---', '')
[System.IO.File]::WriteAllLines($out, [string[]]($header + $lines), $utf8)
Write-Host "Результаты сохранены в $out"
