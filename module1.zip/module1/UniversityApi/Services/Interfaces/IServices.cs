namespace UniversityApi.Services.Interfaces;

public interface IStudentService
{
    Task<ReturnResult<IReadOnlyList<StudentDto>>> GetAllAsync();
    Task<ReturnResult<StudentDto>> GetByIdAsync(int id);
    Task<ReturnResult<StudentWithCoursesDto>> GetWithCoursesAsync(int id);
    Task<ReturnResult<StudentDto>> CreateAsync(StudentCreateDto dto);
    Task<ReturnResult<StudentDto>> UpdateAsync(int id, StudentUpdateDto dto);
    Task<ReturnResult<object>> DeleteAsync(int id);
}

public interface ITeacherService
{
    Task<ReturnResult<IReadOnlyList<TeacherDto>>> GetAllAsync();
    Task<ReturnResult<TeacherDto>> GetByIdAsync(int id);
    Task<ReturnResult<TeacherDto>> CreateAsync(TeacherCreateDto dto);
    Task<ReturnResult<TeacherDto>> UpdateAsync(int id, TeacherUpdateDto dto);
    Task<ReturnResult<object>> DeleteAsync(int id);
}

public interface ICourseService
{
    Task<ReturnResult<IReadOnlyList<CourseDto>>> GetAllAsync(CourseFilterDto filter);
    Task<ReturnResult<CourseDto>> GetByIdAsync(int id);
    Task<ReturnResult<CourseDto>> CreateAsync(CourseCreateDto dto);
    Task<ReturnResult<CourseDto>> UpdateAsync(int id, CourseUpdateDto dto);
    Task<ReturnResult<object>> DeleteAsync(int id);
}

public interface IEnrollmentService
{
    Task<ReturnResult<IReadOnlyList<EnrollmentDto>>> GetAllAsync();
    Task<ReturnResult<EnrollmentDto>> GetByIdAsync(int id);
    Task<ReturnResult<EnrollmentDto>> EnrollAsync(EnrollmentCreateDto dto);
    Task<ReturnResult<EnrollmentDto>> UpdateGradeAsync(int id, EnrollmentGradeDto dto);
    Task<ReturnResult<object>> DeleteAsync(int id);
}
