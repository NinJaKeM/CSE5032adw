namespace UniversityApi.Services.Implementations;

public class EnrollmentService : IEnrollmentService
{
    private readonly IEnrollmentRepository _enrollments;
    private readonly IStudentRepository _students;
    private readonly ICourseRepository _courses;
    private readonly IMapper _mapper;
    private readonly ILogger<EnrollmentService> _logger;

    public EnrollmentService(IEnrollmentRepository enrollments, IStudentRepository students, ICourseRepository courses,
        IMapper mapper, ILogger<EnrollmentService> logger)
    {
        _enrollments = enrollments;
        _students = students;
        _courses = courses;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<IReadOnlyList<EnrollmentDto>>> GetAllAsync()
    {
        var enrollments = await _enrollments.GetAllAsync();
        return ReturnResult<IReadOnlyList<EnrollmentDto>>.Ok(_mapper.Map<IReadOnlyList<EnrollmentDto>>(enrollments));
    }

    public async Task<ReturnResult<EnrollmentDto>> GetByIdAsync(int id)
    {
        var enrollment = await _enrollments.GetByIdAsync(id);
        if (enrollment == null)
        {
            _logger.LogWarning("Enrollment {EnrollmentId} not found", id);
            return ReturnResult<EnrollmentDto>.NotFound(ErrorCodes.EnrollmentNotFound, $"Enrollment with id {id} not found");
        }
        return ReturnResult<EnrollmentDto>.Ok(_mapper.Map<EnrollmentDto>(enrollment));
    }

    public async Task<ReturnResult<EnrollmentDto>> EnrollAsync(EnrollmentCreateDto dto)
    {
        // Правило 2: нельзя записать несуществующего студента
        if (!await _students.ExistsAsync(dto.StudentId))
        {
            _logger.LogWarning("Enrollment failed: student {StudentId} not found", dto.StudentId);
            return ReturnResult<EnrollmentDto>.NotFound(ErrorCodes.StudentNotFound, $"Student with id {dto.StudentId} not found");
        }

        // Правило 1: нельзя записать на несуществующий курс
        if (!await _courses.ExistsAsync(dto.CourseId))
        {
            _logger.LogWarning("Enrollment failed: course {CourseId} not found", dto.CourseId);
            return ReturnResult<EnrollmentDto>.NotFound(ErrorCodes.CourseNotFound, $"Course with id {dto.CourseId} not found");
        }

        // Правило 3: один студент не может быть дважды записан на один курс
        if (await _enrollments.ExistsAsync(dto.StudentId, dto.CourseId))
        {
            _logger.LogWarning("Enrollment failed: student {StudentId} is already enrolled in course {CourseId}", dto.StudentId, dto.CourseId);
            return ReturnResult<EnrollmentDto>.Conflict(ErrorCodes.AlreadyEnrolled, $"Student {dto.StudentId} is already enrolled in course {dto.CourseId}");
        }

        var enrollment = _mapper.Map<Enrollment>(dto);
        await _enrollments.AddAsync(enrollment);

        _logger.LogInformation("Enrollment {EnrollmentId} created: student {StudentId} -> course {CourseId}", enrollment.Id, enrollment.StudentId, enrollment.CourseId);
        return ReturnResult<EnrollmentDto>.Created(_mapper.Map<EnrollmentDto>(enrollment));
    }

    public async Task<ReturnResult<EnrollmentDto>> UpdateGradeAsync(int id, EnrollmentGradeDto dto)
    {
        var enrollment = await _enrollments.GetByIdAsync(id);
        if (enrollment == null)
        {
            _logger.LogWarning("Grade update failed: enrollment {EnrollmentId} not found", id);
            return ReturnResult<EnrollmentDto>.NotFound(ErrorCodes.EnrollmentNotFound, $"Enrollment with id {id} not found");
        }

        var oldGrade = enrollment.Grade;
        enrollment.Grade = dto.Grade;
        await _enrollments.UpdateAsync(enrollment);

        _logger.LogInformation("Enrollment {EnrollmentId} grade changed: {OldGrade} -> {NewGrade}", id, oldGrade, dto.Grade);
        return ReturnResult<EnrollmentDto>.Ok(_mapper.Map<EnrollmentDto>(enrollment));
    }

    public async Task<ReturnResult<object>> DeleteAsync(int id)
    {
        var enrollment = await _enrollments.GetByIdAsync(id);
        if (enrollment == null)
        {
            _logger.LogWarning("Delete failed: enrollment {EnrollmentId} not found", id);
            return ReturnResult<object>.NotFound(ErrorCodes.EnrollmentNotFound, $"Enrollment with id {id} not found");
        }

        await _enrollments.DeleteAsync(enrollment);

        _logger.LogInformation("Enrollment {EnrollmentId} deleted: student {StudentId} removed from course {CourseId}", id, enrollment.StudentId, enrollment.CourseId);
        return ReturnResult<object>.Ok(new { id, message = "Student removed from course" });
    }
}
