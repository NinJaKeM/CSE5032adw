namespace UniversityApi.Services.Implementations;

public class StudentService : IStudentService
{
    private readonly IStudentRepository _students;
    private readonly IMapper _mapper;
    private readonly ILogger<StudentService> _logger;

    public StudentService(IStudentRepository students, IMapper mapper, ILogger<StudentService> logger)
    {
        _students = students;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<IReadOnlyList<StudentDto>>> GetAllAsync()
    {
        var students = await _students.GetAllAsync();
        return ReturnResult<IReadOnlyList<StudentDto>>.Ok(_mapper.Map<IReadOnlyList<StudentDto>>(students));
    }

    public async Task<ReturnResult<StudentDto>> GetByIdAsync(int id)
    {
        var student = await _students.GetByIdAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Student {StudentId} not found", id);
            return ReturnResult<StudentDto>.NotFound(ErrorCodes.StudentNotFound, $"Student with id {id} not found");
        }
        return ReturnResult<StudentDto>.Ok(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<StudentWithCoursesDto>> GetWithCoursesAsync(int id)
    {
        var student = await _students.GetWithCoursesAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Student {StudentId} not found", id);
            return ReturnResult<StudentWithCoursesDto>.NotFound(ErrorCodes.StudentNotFound, $"Student with id {id} not found");
        }
        return ReturnResult<StudentWithCoursesDto>.Ok(_mapper.Map<StudentWithCoursesDto>(student));
    }

    public async Task<ReturnResult<StudentDto>> CreateAsync(StudentCreateDto dto)
    {
        if (await _students.EmailExistsAsync(dto.Email))
        {
            _logger.LogWarning("Student with email {Email} already exists", dto.Email);
            return ReturnResult<StudentDto>.Conflict(ErrorCodes.StudentEmailExists, $"Student with email {dto.Email} already exists");
        }

        var student = _mapper.Map<Student>(dto);
        await _students.AddAsync(student);

        _logger.LogInformation("Student {StudentId} created: {FirstName} {LastName}", student.Id, student.FirstName, student.LastName);
        return ReturnResult<StudentDto>.Created(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<StudentDto>> UpdateAsync(int id, StudentUpdateDto dto)
    {
        var student = await _students.GetByIdAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Update failed: student {StudentId} not found", id);
            return ReturnResult<StudentDto>.NotFound(ErrorCodes.StudentNotFound, $"Student with id {id} not found");
        }
        if (await _students.EmailExistsAsync(dto.Email, id))
        {
            _logger.LogWarning("Update failed: email {Email} is used by another student", dto.Email);
            return ReturnResult<StudentDto>.Conflict(ErrorCodes.StudentEmailExists, $"Student with email {dto.Email} already exists");
        }

        _mapper.Map(dto, student);
        await _students.UpdateAsync(student);

        _logger.LogInformation("Student {StudentId} updated", id);
        return ReturnResult<StudentDto>.Ok(_mapper.Map<StudentDto>(student));
    }

    public async Task<ReturnResult<object>> DeleteAsync(int id)
    {
        var student = await _students.GetByIdAsync(id);
        if (student == null)
        {
            _logger.LogWarning("Delete failed: student {StudentId} not found", id);
            return ReturnResult<object>.NotFound(ErrorCodes.StudentNotFound, $"Student with id {id} not found");
        }

        await _students.DeleteAsync(student);

        _logger.LogInformation("Student {StudentId} deleted", id);
        return ReturnResult<object>.Ok(new { id, message = "Student deleted" });
    }
}
