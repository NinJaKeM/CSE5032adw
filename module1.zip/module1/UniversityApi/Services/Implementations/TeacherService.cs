namespace UniversityApi.Services.Implementations;

public class TeacherService : ITeacherService
{
    private readonly ITeacherRepository _teachers;
    private readonly IMapper _mapper;
    private readonly ILogger<TeacherService> _logger;

    public TeacherService(ITeacherRepository teachers, IMapper mapper, ILogger<TeacherService> logger)
    {
        _teachers = teachers;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<IReadOnlyList<TeacherDto>>> GetAllAsync()
    {
        var teachers = await _teachers.GetAllAsync();
        return ReturnResult<IReadOnlyList<TeacherDto>>.Ok(_mapper.Map<IReadOnlyList<TeacherDto>>(teachers));
    }

    public async Task<ReturnResult<TeacherDto>> GetByIdAsync(int id)
    {
        var teacher = await _teachers.GetByIdAsync(id);
        if (teacher == null)
        {
            _logger.LogWarning("Teacher {TeacherId} not found", id);
            return ReturnResult<TeacherDto>.NotFound(ErrorCodes.TeacherNotFound, $"Teacher with id {id} not found");
        }
        return ReturnResult<TeacherDto>.Ok(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<TeacherDto>> CreateAsync(TeacherCreateDto dto)
    {
        if (await _teachers.EmailExistsAsync(dto.Email))
        {
            _logger.LogWarning("Teacher with email {Email} already exists", dto.Email);
            return ReturnResult<TeacherDto>.Conflict(ErrorCodes.TeacherEmailExists, $"Teacher with email {dto.Email} already exists");
        }

        var teacher = _mapper.Map<Teacher>(dto);
        await _teachers.AddAsync(teacher);

        _logger.LogInformation("Teacher {TeacherId} created: {FirstName} {LastName}", teacher.Id, teacher.FirstName, teacher.LastName);
        return ReturnResult<TeacherDto>.Created(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<TeacherDto>> UpdateAsync(int id, TeacherUpdateDto dto)
    {
        var teacher = await _teachers.GetByIdAsync(id);
        if (teacher == null)
        {
            _logger.LogWarning("Update failed: teacher {TeacherId} not found", id);
            return ReturnResult<TeacherDto>.NotFound(ErrorCodes.TeacherNotFound, $"Teacher with id {id} not found");
        }
        if (await _teachers.EmailExistsAsync(dto.Email, id))
        {
            _logger.LogWarning("Update failed: email {Email} is used by another teacher", dto.Email);
            return ReturnResult<TeacherDto>.Conflict(ErrorCodes.TeacherEmailExists, $"Teacher with email {dto.Email} already exists");
        }

        _mapper.Map(dto, teacher);
        await _teachers.UpdateAsync(teacher);

        _logger.LogInformation("Teacher {TeacherId} updated", id);
        return ReturnResult<TeacherDto>.Ok(_mapper.Map<TeacherDto>(teacher));
    }

    public async Task<ReturnResult<object>> DeleteAsync(int id)
    {
        var teacher = await _teachers.GetByIdAsync(id);
        if (teacher == null)
        {
            _logger.LogWarning("Delete failed: teacher {TeacherId} not found", id);
            return ReturnResult<object>.NotFound(ErrorCodes.TeacherNotFound, $"Teacher with id {id} not found");
        }
        if (await _teachers.HasCoursesAsync(id))
        {
            _logger.LogWarning("Delete failed: teacher {TeacherId} still has courses", id);
            return ReturnResult<object>.Conflict(ErrorCodes.TeacherHasCourses, "Teacher cannot be deleted while assigned to courses");
        }

        await _teachers.DeleteAsync(teacher);

        _logger.LogInformation("Teacher {TeacherId} deleted", id);
        return ReturnResult<object>.Ok(new { id, message = "Teacher deleted" });
    }
}
