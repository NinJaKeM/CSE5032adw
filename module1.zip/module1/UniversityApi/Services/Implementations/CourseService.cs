namespace UniversityApi.Services.Implementations;

public class CourseService : ICourseService
{
    private readonly ICourseRepository _courses;
    private readonly ITeacherRepository _teachers;
    private readonly IMapper _mapper;
    private readonly ILogger<CourseService> _logger;

    public CourseService(ICourseRepository courses, ITeacherRepository teachers, IMapper mapper, ILogger<CourseService> logger)
    {
        _courses = courses;
        _teachers = teachers;
        _mapper = mapper;
        _logger = logger;
    }

    public async Task<ReturnResult<IReadOnlyList<CourseDto>>> GetAllAsync(CourseFilterDto filter)
    {
        var courses = await _courses.GetAllAsync(filter);
        return ReturnResult<IReadOnlyList<CourseDto>>.Ok(_mapper.Map<IReadOnlyList<CourseDto>>(courses));
    }

    public async Task<ReturnResult<CourseDto>> GetByIdAsync(int id)
    {
        var course = await _courses.GetByIdAsync(id);
        if (course == null)
        {
            _logger.LogWarning("Course {CourseId} not found", id);
            return ReturnResult<CourseDto>.NotFound(ErrorCodes.CourseNotFound, $"Course with id {id} not found");
        }
        return ReturnResult<CourseDto>.Ok(_mapper.Map<CourseDto>(course));
    }

    public async Task<ReturnResult<CourseDto>> CreateAsync(CourseCreateDto dto)
    {
        // Правило 4: курс не может ссылаться на несуществующего преподавателя
        if (!await _teachers.ExistsAsync(dto.TeacherId))
        {
            _logger.LogWarning("Course creation failed: teacher {TeacherId} not found", dto.TeacherId);
            return ReturnResult<CourseDto>.NotFound(ErrorCodes.TeacherNotFound, $"Teacher with id {dto.TeacherId} not found");
        }

        var course = _mapper.Map<Course>(dto);
        await _courses.AddAsync(course);

        _logger.LogInformation("Course {CourseId} '{CourseName}' created for teacher {TeacherId}", course.Id, course.Name, course.TeacherId);
        return ReturnResult<CourseDto>.Created(_mapper.Map<CourseDto>(course));
    }

    public async Task<ReturnResult<CourseDto>> UpdateAsync(int id, CourseUpdateDto dto)
    {
        var course = await _courses.GetByIdAsync(id);
        if (course == null)
        {
            _logger.LogWarning("Update failed: course {CourseId} not found", id);
            return ReturnResult<CourseDto>.NotFound(ErrorCodes.CourseNotFound, $"Course with id {id} not found");
        }
        if (!await _teachers.ExistsAsync(dto.TeacherId))
        {
            _logger.LogWarning("Update failed: teacher {TeacherId} not found", dto.TeacherId);
            return ReturnResult<CourseDto>.NotFound(ErrorCodes.TeacherNotFound, $"Teacher with id {dto.TeacherId} not found");
        }

        _mapper.Map(dto, course);
        course.Teacher = null;
        await _courses.UpdateAsync(course);

        _logger.LogInformation("Course {CourseId} updated", id);
        return ReturnResult<CourseDto>.Ok(_mapper.Map<CourseDto>(course));
    }

    public async Task<ReturnResult<object>> DeleteAsync(int id)
    {
        var course = await _courses.GetByIdAsync(id);
        if (course == null)
        {
            _logger.LogWarning("Delete failed: course {CourseId} not found", id);
            return ReturnResult<object>.NotFound(ErrorCodes.CourseNotFound, $"Course with id {id} not found");
        }

        await _courses.DeleteAsync(course);

        _logger.LogInformation("Course {CourseId} deleted", id);
        return ReturnResult<object>.Ok(new { id, message = "Course deleted" });
    }
}
