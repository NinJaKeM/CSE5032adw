using System.ComponentModel.DataAnnotations;

namespace UniversityApi.Dtos.Courses;

/// <summary>Курс в ответе API.</summary>
public class CourseDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int Credits { get; set; }
    public int TeacherId { get; set; }
    public string TeacherName { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}

/// <summary>Данные для создания курса.</summary>
public class CourseCreateDto
{
    [Required(ErrorMessage = "Course name is required")]
    [StringLength(150, MinimumLength = 1)]
    public string Name { get; set; } = string.Empty;

    [StringLength(1000)]
    public string Description { get; set; } = string.Empty;

    [Range(1, 10, ErrorMessage = "Credits must be between 1 and 10")]
    public int Credits { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "TeacherId must be a positive number")]
    public int TeacherId { get; set; }
}

/// <summary>Данные для изменения курса.</summary>
public class CourseUpdateDto : CourseCreateDto
{
}

/// <summary>Параметры фильтрации курсов (query string).</summary>
public class CourseFilterDto
{
    /// <summary>Только курсы этого преподавателя.</summary>
    public int? TeacherId { get; set; }

    /// <summary>Минимальное количество кредитов.</summary>
    [Range(1, 10)]
    public int? MinCredits { get; set; }

    /// <summary>Максимальное количество кредитов.</summary>
    [Range(1, 10)]
    public int? MaxCredits { get; set; }

    /// <summary>Поиск по части названия.</summary>
    [StringLength(150)]
    public string? Search { get; set; }
}
