using System.ComponentModel.DataAnnotations;

namespace UniversityApi.Dtos.Students;

/// <summary>Студент в ответе API.</summary>
public class StudentDto
{
    public int Id { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public DateTime BirthDate { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>Данные для создания студента.</summary>
public class StudentCreateDto : IValidatableObject
{
    [Required(ErrorMessage = "FirstName is required")]
    [StringLength(100, MinimumLength = 1)]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "LastName is required")]
    [StringLength(100, MinimumLength = 1)]
    public string LastName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Email has invalid format")]
    [StringLength(200)]
    public string Email { get; set; } = string.Empty;

    [Required]
    public DateTime BirthDate { get; set; }

    public IEnumerable<ValidationResult> Validate(System.ComponentModel.DataAnnotations.ValidationContext validationContext)
    {
        var today = DateTime.Today;
        if (BirthDate > today.AddYears(-14) || BirthDate < today.AddYears(-100))
        {
            yield return new ValidationResult("BirthDate must correspond to an age between 14 and 100 years", new[] { nameof(BirthDate) });
        }
    }
}

/// <summary>Данные для изменения студента (все поля обязательны).</summary>
public class StudentUpdateDto : StudentCreateDto
{
}

/// <summary>Курс, на который записан студент.</summary>
public class StudentCourseDto
{
    public int EnrollmentId { get; set; }
    public int CourseId { get; set; }
    public string CourseName { get; set; } = string.Empty;
    public int Credits { get; set; }
    public string TeacherName { get; set; } = string.Empty;
    public DateTime EnrollmentDate { get; set; }
    public int? Grade { get; set; }
}

/// <summary>Студент вместе со списком его курсов.</summary>
public class StudentWithCoursesDto : StudentDto
{
    [System.Text.Json.Serialization.JsonPropertyOrder(1)]
    public List<StudentCourseDto> Courses { get; set; } = new();
}
