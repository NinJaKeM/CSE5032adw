namespace UniversityApi.Data;

// Тестовые данные, попадают в базу через миграцию (HasData)
public static class SeedData
{
    private static readonly DateTime Created = new(2026, 9, 1, 9, 0, 0, DateTimeKind.Utc);

    public static void Apply(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Teacher>().HasData(
            new Teacher { Id = 1, FirstName = "Aigerim", LastName = "Sadykova", Email = "aigerim.sadykova@university.kz", Department = "Software Engineering" },
            new Teacher { Id = 2, FirstName = "Daniyar", LastName = "Abenov", Email = "daniyar.abenov@university.kz", Department = "Computer Science" },
            new Teacher { Id = 3, FirstName = "Marat", LastName = "Iskakov", Email = "marat.iskakov@university.kz", Department = "Mathematics" });

        modelBuilder.Entity<Student>().HasData(
            new Student { Id = 1, FirstName = "Ivan", LastName = "Ivanov", Email = "ivan.ivanov@student.kz", BirthDate = new DateTime(2004, 3, 15), CreatedAt = Created },
            new Student { Id = 2, FirstName = "Anna", LastName = "Petrova", Email = "anna.petrova@student.kz", BirthDate = new DateTime(2005, 7, 22), CreatedAt = Created },
            new Student { Id = 3, FirstName = "Maxim", LastName = "Kim", Email = "maxim.kim@student.kz", BirthDate = new DateTime(2004, 11, 2), CreatedAt = Created },
            new Student { Id = 4, FirstName = "Aliya", LastName = "Seitkazy", Email = "aliya.seitkazy@student.kz", BirthDate = new DateTime(2005, 1, 30), CreatedAt = Created });

        modelBuilder.Entity<Course>().HasData(
            new Course { Id = 1, Name = "Web Services Development", Description = "ASP.NET Core Web API, REST, EF Core", Credits = 5, TeacherId = 1, CreatedAt = Created },
            new Course { Id = 2, Name = "Databases", Description = "Relational databases and SQL", Credits = 4, TeacherId = 2, CreatedAt = Created },
            new Course { Id = 3, Name = "Algorithms and Data Structures", Description = "Sorting, graphs, complexity", Credits = 6, TeacherId = 2, CreatedAt = Created },
            new Course { Id = 4, Name = "Linear Algebra", Description = "Matrices, vector spaces", Credits = 3, TeacherId = 3, CreatedAt = Created });

        modelBuilder.Entity<Enrollment>().HasData(
            new Enrollment { Id = 1, StudentId = 1, CourseId = 1, EnrollmentDate = Created, Grade = 90 },
            new Enrollment { Id = 2, StudentId = 1, CourseId = 2, EnrollmentDate = Created, Grade = null },
            new Enrollment { Id = 3, StudentId = 2, CourseId = 1, EnrollmentDate = Created, Grade = 85 },
            new Enrollment { Id = 4, StudentId = 3, CourseId = 3, EnrollmentDate = Created, Grade = null },
            new Enrollment { Id = 5, StudentId = 4, CourseId = 4, EnrollmentDate = Created, Grade = 78 });
    }
}
