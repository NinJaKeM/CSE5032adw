using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace UniversityApi.Data.Configurations;

public class TeacherConfiguration : IEntityTypeConfiguration<Teacher>
{
    public void Configure(EntityTypeBuilder<Teacher> builder)
    {
        builder.ToTable("Teachers");
        builder.HasKey(t => t.Id);

        builder.HasIndex(t => t.Email).IsUnique();
    }
}
