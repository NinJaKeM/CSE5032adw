using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace UniversityApi.Data.Configurations;

public class CourseConfiguration : IEntityTypeConfiguration<Course>
{
    public void Configure(EntityTypeBuilder<Course> builder)
    {
        builder.ToTable("Courses", t => t.HasCheckConstraint("CK_Courses_Credits", "[Credits] BETWEEN 1 AND 10"));
        builder.HasKey(c => c.Id);

        builder.Property(c => c.Name).IsRequired().HasMaxLength(150);
        builder.Property(c => c.Description).IsRequired().HasMaxLength(1000);
        builder.Property(c => c.CreatedAt).HasDefaultValueSql("GETUTCDATE()");

        // Курс закреплён за преподавателем; преподавателя с курсами удалить нельзя
        builder.HasOne(c => c.Teacher)
            .WithMany(t => t.Courses)
            .HasForeignKey(c => c.TeacherId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
