using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace UniversityApi.Data.Configurations;

public class StudentConfiguration : IEntityTypeConfiguration<Student>
{
    public void Configure(EntityTypeBuilder<Student> builder)
    {
        builder.ToTable("Students");
        builder.HasKey(s => s.Id);

        builder.HasIndex(s => s.Email).IsUnique();

        builder.Property(s => s.BirthDate).HasColumnType("date");
        builder.Property(s => s.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
    }
}
