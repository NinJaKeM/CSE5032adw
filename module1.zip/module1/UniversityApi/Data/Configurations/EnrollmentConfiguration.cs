using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace UniversityApi.Data.Configurations;

public class EnrollmentConfiguration : IEntityTypeConfiguration<Enrollment>
{
    public void Configure(EntityTypeBuilder<Enrollment> builder)
    {
        builder.ToTable("Enrollments", t => t.HasCheckConstraint("CK_Enrollments_Grade", "[Grade] IS NULL OR [Grade] BETWEEN 0 AND 100"));
        builder.HasKey(e => e.Id);

        builder.Property(e => e.EnrollmentDate).HasDefaultValueSql("GETUTCDATE()");

        // Один студент не может быть записан на один курс дважды
        builder.HasIndex(e => new { e.StudentId, e.CourseId }).IsUnique();

        builder.HasOne(e => e.Student)
            .WithMany(s => s.Enrollments)
            .HasForeignKey(e => e.StudentId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasOne(e => e.Course)
            .WithMany(c => c.Enrollments)
            .HasForeignKey(e => e.CourseId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
