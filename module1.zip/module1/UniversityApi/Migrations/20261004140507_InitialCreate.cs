﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace UniversityApi.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    BirthDate = table.Column<DateTime>(type: "date", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Teachers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: false),
                    Department = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Teachers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Courses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false),
                    Credits = table.Column<int>(type: "int", nullable: false),
                    TeacherId = table.Column<int>(type: "int", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Courses", x => x.Id);
                    table.CheckConstraint("CK_Courses_Credits", "[Credits] BETWEEN 1 AND 10");
                    table.ForeignKey(
                        name: "FK_Courses_Teachers_TeacherId",
                        column: x => x.TeacherId,
                        principalTable: "Teachers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Enrollments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StudentId = table.Column<int>(type: "int", nullable: false),
                    CourseId = table.Column<int>(type: "int", nullable: false),
                    EnrollmentDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETUTCDATE()"),
                    Grade = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Enrollments", x => x.Id);
                    table.CheckConstraint("CK_Enrollments_Grade", "[Grade] IS NULL OR [Grade] BETWEEN 0 AND 100");
                    table.ForeignKey(
                        name: "FK_Enrollments_Courses_CourseId",
                        column: x => x.CourseId,
                        principalTable: "Courses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Enrollments_Students_StudentId",
                        column: x => x.StudentId,
                        principalTable: "Students",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Students",
                columns: new[] { "Id", "BirthDate", "CreatedAt", "Email", "FirstName", "LastName" },
                values: new object[,]
                {
                    { 1, new DateTime(2004, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), "ivan.ivanov@student.kz", "Ivan", "Ivanov" },
                    { 2, new DateTime(2005, 7, 22, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), "anna.petrova@student.kz", "Anna", "Petrova" },
                    { 3, new DateTime(2004, 11, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), "maxim.kim@student.kz", "Maxim", "Kim" },
                    { 4, new DateTime(2005, 1, 30, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), "aliya.seitkazy@student.kz", "Aliya", "Seitkazy" }
                });

            migrationBuilder.InsertData(
                table: "Teachers",
                columns: new[] { "Id", "Department", "Email", "FirstName", "LastName" },
                values: new object[,]
                {
                    { 1, "Software Engineering", "aigerim.sadykova@university.kz", "Aigerim", "Sadykova" },
                    { 2, "Computer Science", "daniyar.abenov@university.kz", "Daniyar", "Abenov" },
                    { 3, "Mathematics", "marat.iskakov@university.kz", "Marat", "Iskakov" }
                });

            migrationBuilder.InsertData(
                table: "Courses",
                columns: new[] { "Id", "CreatedAt", "Credits", "Description", "Name", "TeacherId" },
                values: new object[,]
                {
                    { 1, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), 5, "ASP.NET Core Web API, REST, EF Core", "Web Services Development", 1 },
                    { 2, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), 4, "Relational databases and SQL", "Databases", 2 },
                    { 3, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), 6, "Sorting, graphs, complexity", "Algorithms and Data Structures", 2 },
                    { 4, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), 3, "Matrices, vector spaces", "Linear Algebra", 3 }
                });

            migrationBuilder.InsertData(
                table: "Enrollments",
                columns: new[] { "Id", "CourseId", "EnrollmentDate", "Grade", "StudentId" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), 90, 1 },
                    { 2, 2, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), null, 1 },
                    { 3, 1, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), 85, 2 },
                    { 4, 3, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), null, 3 },
                    { 5, 4, new DateTime(2026, 9, 1, 9, 0, 0, 0, DateTimeKind.Utc), 78, 4 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Courses_TeacherId",
                table: "Courses",
                column: "TeacherId");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollments_CourseId",
                table: "Enrollments",
                column: "CourseId");

            migrationBuilder.CreateIndex(
                name: "IX_Enrollments_StudentId_CourseId",
                table: "Enrollments",
                columns: new[] { "StudentId", "CourseId" },
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Students_Email",
                table: "Students",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Teachers_Email",
                table: "Teachers",
                column: "Email",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Enrollments");

            migrationBuilder.DropTable(
                name: "Courses");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Teachers");
        }
    }
}
