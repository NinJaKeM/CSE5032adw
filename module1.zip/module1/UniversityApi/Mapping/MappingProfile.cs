namespace UniversityApi.Mapping;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        // Students
        CreateMap<Student, StudentDto>();
        CreateMap<Student, StudentWithCoursesDto>()
            .ForMember(d => d.Courses, o => o.MapFrom(s => s.Enrollments));
        CreateMap<StudentCreateDto, Student>();
        CreateMap<StudentUpdateDto, Student>();
        CreateMap<Enrollment, StudentCourseDto>()
            .ForMember(d => d.EnrollmentId, o => o.MapFrom(e => e.Id))
            .ForMember(d => d.CourseName, o => o.MapFrom(e => e.Course!.Name))
            .ForMember(d => d.Credits, o => o.MapFrom(e => e.Course!.Credits))
            .ForMember(d => d.TeacherName, o => o.MapFrom(e => e.Course!.Teacher!.FirstName + " " + e.Course.Teacher.LastName));

        // Teachers
        CreateMap<Teacher, TeacherDto>();
        CreateMap<TeacherCreateDto, Teacher>();
        CreateMap<TeacherUpdateDto, Teacher>();

        // Courses
        CreateMap<Course, CourseDto>()
            .ForMember(d => d.TeacherName, o => o.MapFrom(c => c.Teacher == null ? string.Empty : c.Teacher.FirstName + " " + c.Teacher.LastName));
        CreateMap<CourseCreateDto, Course>();
        CreateMap<CourseUpdateDto, Course>();

        // Enrollments
        CreateMap<Enrollment, EnrollmentDto>()
            .ForMember(d => d.StudentName, o => o.MapFrom(e => e.Student == null ? string.Empty : e.Student.FirstName + " " + e.Student.LastName))
            .ForMember(d => d.CourseName, o => o.MapFrom(e => e.Course == null ? string.Empty : e.Course.Name));
        CreateMap<EnrollmentCreateDto, Enrollment>();
    }
}
