namespace UniversityApi.Models;

// Связь многие-ко-многим Student ↔ Course с дополнительными полями; настройка в EnrollmentConfiguration
public class Enrollment
{
    public int Id { get; set; }
    public int StudentId { get; set; }
    public int CourseId { get; set; }
    public DateTime EnrollmentDate { get; set; }
    public int? Grade { get; set; }

    public Student? Student { get; set; }
    public Course? Course { get; set; }
}
