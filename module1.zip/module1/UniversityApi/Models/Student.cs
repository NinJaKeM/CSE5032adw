using System.ComponentModel.DataAnnotations;

namespace UniversityApi.Models;

// Конфигурация через Data Annotations + Fluent API (StudentConfiguration)
public class Student
{
    public int Id { get; set; }

    [Required]
    [MaxLength(100)]
    public string FirstName { get; set; } = string.Empty;

    [Required]
    [MaxLength(100)]
    public string LastName { get; set; } = string.Empty;

    [Required]
    [MaxLength(200)]
    public string Email { get; set; } = string.Empty;

    public DateTime BirthDate { get; set; }

    public DateTime CreatedAt { get; set; }

    public ICollection<Enrollment> Enrollments { get; set; } = new List<Enrollment>();
}
