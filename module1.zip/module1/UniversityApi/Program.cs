using System.Reflection;
using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using UniversityApi.Middleware;
using UniversityApi.Repositories.Implementations;
using UniversityApi.Services.Implementations;

var builder = WebApplication.CreateBuilder(args);

// Логирование: однострочный формат с временем
builder.Logging.ClearProviders();
builder.Logging.AddSimpleConsole(options =>
{
    options.SingleLine = true;
    options.TimestampFormat = "HH:mm:ss ";
});

builder.Services.AddControllers()
    .ConfigureApiBehaviorOptions(options =>
    {
        // Ошибки валидации DTO возвращаются в едином формате ReturnResult (400 VALIDATION_ERROR)
        options.InvalidModelStateResponseFactory = context =>
        {
            var errors = context.ModelState
                .Where(entry => entry.Value!.Errors.Count > 0)
                .ToDictionary(
                    entry => entry.Key,
                    entry => entry.Value!.Errors.Select(e => string.IsNullOrEmpty(e.ErrorMessage) ? "Invalid value" : e.ErrorMessage).ToArray());

            var result = ReturnResult<object>.Fail(StatusCodes.Status400BadRequest, ErrorCodes.ValidationError,
                "One or more validation errors occurred", errors);
            result.TraceId = context.HttpContext.TraceIdentifier;

            context.HttpContext.RequestServices.GetRequiredService<ILogger<Program>>()
                .LogWarning("Validation failed for {Method} {Path}: {Fields}", context.HttpContext.Request.Method,
                    context.HttpContext.Request.Path, string.Join(", ", errors.Keys));

            return new BadRequestObjectResult(result);
        };
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "University Course Management API",
        Version = "v1",
        Description = "Студенты, преподаватели, курсы и записи на курсы. Все ответы — в формате ReturnResult."
    });
    var xmlFile = Path.Combine(AppContext.BaseDirectory, $"{Assembly.GetExecutingAssembly().GetName().Name}.xml");
    options.IncludeXmlComments(xmlFile);
});

// EF Core: DbContext регистрируется как Scoped (один экземпляр на HTTP-запрос)
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Repository и Service — Scoped: они используют DbContext, который живёт в рамках запроса
builder.Services.AddScoped<IStudentRepository, StudentRepository>();
builder.Services.AddScoped<ITeacherRepository, TeacherRepository>();
builder.Services.AddScoped<ICourseRepository, CourseRepository>();
builder.Services.AddScoped<IEnrollmentRepository, EnrollmentRepository>();

builder.Services.AddScoped<IStudentService, StudentService>();
builder.Services.AddScoped<ITeacherService, TeacherService>();
builder.Services.AddScoped<ICourseService, CourseService>();
builder.Services.AddScoped<IEnrollmentService, EnrollmentService>();

// AutoMapper: конфигурация маппинга создаётся один раз (профили из сборки)
builder.Services.AddAutoMapper(typeof(Program));

var app = builder.Build();

// Middleware обработки ошибок — первым в конвейере, чтобы перехватывать исключения всех последующих компонентов
app.UseMiddleware<ExceptionHandlingMiddleware>();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options => options.DocumentTitle = "University Course Management API");
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
