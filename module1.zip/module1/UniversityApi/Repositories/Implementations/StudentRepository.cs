namespace UniversityApi.Repositories.Implementations;

public class StudentRepository : IStudentRepository
{
    private readonly ApplicationDbContext _context;

    public StudentRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IReadOnlyList<Student>> GetAllAsync() =>
        await _context.Students.AsNoTracking().OrderBy(s => s.Id).ToListAsync();

    public Task<Student?> GetByIdAsync(int id) =>
        _context.Students.FirstOrDefaultAsync(s => s.Id == id);

    public Task<Student?> GetWithCoursesAsync(int id) =>
        _context.Students
            .AsNoTracking()
            .Include(s => s.Enrollments).ThenInclude(e => e.Course).ThenInclude(c => c!.Teacher)
            .FirstOrDefaultAsync(s => s.Id == id);

    public Task<bool> ExistsAsync(int id) =>
        _context.Students.AnyAsync(s => s.Id == id);

    public Task<bool> EmailExistsAsync(string email, int? excludeId = null) =>
        _context.Students.AnyAsync(s => s.Email == email && (excludeId == null || s.Id != excludeId));

    public async Task AddAsync(Student student)
    {
        _context.Students.Add(student);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Student student)
    {
        _context.Students.Update(student);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(Student student)
    {
        _context.Students.Remove(student);
        await _context.SaveChangesAsync();
    }
}
