namespace UniversityApi.Repositories.Implementations;

public class TeacherRepository : ITeacherRepository
{
    private readonly ApplicationDbContext _context;

    public TeacherRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IReadOnlyList<Teacher>> GetAllAsync() =>
        await _context.Teachers.AsNoTracking().OrderBy(t => t.Id).ToListAsync();

    public Task<Teacher?> GetByIdAsync(int id) =>
        _context.Teachers.FirstOrDefaultAsync(t => t.Id == id);

    public Task<bool> ExistsAsync(int id) =>
        _context.Teachers.AnyAsync(t => t.Id == id);

    public Task<bool> EmailExistsAsync(string email, int? excludeId = null) =>
        _context.Teachers.AnyAsync(t => t.Email == email && (excludeId == null || t.Id != excludeId));

    public Task<bool> HasCoursesAsync(int id) =>
        _context.Courses.AnyAsync(c => c.TeacherId == id);

    public async Task AddAsync(Teacher teacher)
    {
        _context.Teachers.Add(teacher);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Teacher teacher)
    {
        _context.Teachers.Update(teacher);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(Teacher teacher)
    {
        _context.Teachers.Remove(teacher);
        await _context.SaveChangesAsync();
    }
}
