namespace UniversityApi.Repositories.Implementations;

public class CourseRepository : ICourseRepository
{
    private readonly ApplicationDbContext _context;

    public CourseRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IReadOnlyList<Course>> GetAllAsync(CourseFilterDto filter)
    {
        var query = _context.Courses.AsNoTracking().Include(c => c.Teacher).AsQueryable();

        if (filter.TeacherId.HasValue)
            query = query.Where(c => c.TeacherId == filter.TeacherId);
        if (filter.MinCredits.HasValue)
            query = query.Where(c => c.Credits >= filter.MinCredits);
        if (filter.MaxCredits.HasValue)
            query = query.Where(c => c.Credits <= filter.MaxCredits);
        if (!string.IsNullOrWhiteSpace(filter.Search))
            query = query.Where(c => c.Name.Contains(filter.Search));

        return await query.OrderBy(c => c.Id).ToListAsync();
    }

    public Task<Course?> GetByIdAsync(int id) =>
        _context.Courses.Include(c => c.Teacher).FirstOrDefaultAsync(c => c.Id == id);

    public Task<bool> ExistsAsync(int id) =>
        _context.Courses.AnyAsync(c => c.Id == id);

    public async Task AddAsync(Course course)
    {
        _context.Courses.Add(course);
        await _context.SaveChangesAsync();
        await _context.Entry(course).Reference(c => c.Teacher).LoadAsync();
    }

    public async Task UpdateAsync(Course course)
    {
        _context.Courses.Update(course);
        await _context.SaveChangesAsync();
        await _context.Entry(course).Reference(c => c.Teacher).LoadAsync();
    }

    public async Task DeleteAsync(Course course)
    {
        _context.Courses.Remove(course);
        await _context.SaveChangesAsync();
    }
}
