using System.Text.Json.Serialization;

namespace UniversityApi.Common;

/// <summary>Единый формат ответа API.</summary>
public class ReturnResult<T>
{
    public int StatusCode { get; set; }
    public bool IsSuccess { get; set; }
    public T? Result { get; set; }
    public string? ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }

    /// <summary>Ошибки валидации по полям (только для 400 VALIDATION_ERROR).</summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public Dictionary<string, string[]>? Errors { get; set; }

    public string? TraceId { get; set; }

    public static ReturnResult<T> Ok(T result, int statusCode = StatusCodes.Status200OK) =>
        new() { StatusCode = statusCode, IsSuccess = true, Result = result };

    public static ReturnResult<T> Created(T result) => Ok(result, StatusCodes.Status201Created);

    public static ReturnResult<T> Fail(int statusCode, string errorCode, string errorMessage, Dictionary<string, string[]>? errors = null) =>
        new() { StatusCode = statusCode, IsSuccess = false, ErrorCode = errorCode, ErrorMessage = errorMessage, Errors = errors };

    public static ReturnResult<T> NotFound(string errorCode, string errorMessage) =>
        Fail(StatusCodes.Status404NotFound, errorCode, errorMessage);

    public static ReturnResult<T> Conflict(string errorCode, string errorMessage) =>
        Fail(StatusCodes.Status409Conflict, errorCode, errorMessage);
}
