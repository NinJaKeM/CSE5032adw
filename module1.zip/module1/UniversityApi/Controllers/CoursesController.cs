using Microsoft.AspNetCore.Mvc;

namespace UniversityApi.Controllers;

[Route("api/courses")]
public class CoursesController : ApiControllerBase
{
    private readonly ICourseService _service;

    public CoursesController(ICourseService service)
    {
        _service = service;
    }

    /// <summary>Получить курсы с фильтрацией по преподавателю, кредитам и названию.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<IReadOnlyList<CourseDto>>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<ReturnResult<IReadOnlyList<CourseDto>>>> GetAll([FromQuery] CourseFilterDto filter) =>
        ToResult(await _service.GetAllAsync(filter));

    /// <summary>Получить курс по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<CourseDto>>> GetById(int id) =>
        ToResult(await _service.GetByIdAsync(id));

    /// <summary>Создать курс и закрепить его за преподавателем.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<CourseDto>>> Create(CourseCreateDto dto) =>
        ToCreated(await _service.CreateAsync(dto), nameof(GetById), c => new { id = c.Id });

    /// <summary>Изменить курс.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<CourseDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<CourseDto>>> Update(int id, CourseUpdateDto dto) =>
        ToResult(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить курс (записи на него удаляются каскадно).</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<object>>> Delete(int id) =>
        ToResult(await _service.DeleteAsync(id));
}
