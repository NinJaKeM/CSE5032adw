using Microsoft.AspNetCore.Mvc;

namespace UniversityApi.Controllers;

/// <summary>Служебный endpoint для проверки централизованной обработки ошибок (только Development).</summary>
[Route("api/diagnostics")]
public class DiagnosticsController : ApiControllerBase
{
    private readonly IWebHostEnvironment _environment;

    public DiagnosticsController(IWebHostEnvironment environment)
    {
        _environment = environment;
    }

    /// <summary>Сгенерировать непредвиденное исключение (проверка ответа 500).</summary>
    [HttpGet("error")]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status500InternalServerError)]
    public IActionResult ThrowError()
    {
        if (!_environment.IsDevelopment())
        {
            return NotFound();
        }
        throw new InvalidOperationException("Simulated failure: SELECT * FROM Students WHERE ... (connection string, stack trace must not leak)");
    }
}
