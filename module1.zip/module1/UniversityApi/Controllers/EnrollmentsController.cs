using Microsoft.AspNetCore.Mvc;

namespace UniversityApi.Controllers;

[Route("api/enrollments")]
public class EnrollmentsController : ApiControllerBase
{
    private readonly IEnrollmentService _service;

    public EnrollmentsController(IEnrollmentService service)
    {
        _service = service;
    }

    /// <summary>Получить список записей на курсы.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<IReadOnlyList<EnrollmentDto>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ReturnResult<IReadOnlyList<EnrollmentDto>>>> GetAll() =>
        ToResult(await _service.GetAllAsync());

    /// <summary>Получить запись по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<EnrollmentDto>>> GetById(int id) =>
        ToResult(await _service.GetByIdAsync(id));

    /// <summary>Записать студента на курс.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ReturnResult<EnrollmentDto>>> Enroll(EnrollmentCreateDto dto) =>
        ToCreated(await _service.EnrollAsync(dto), nameof(GetById), e => new { id = e.Id });

    /// <summary>Изменить оценку студента.</summary>
    [HttpPut("{id:int}/grade")]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<EnrollmentDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<EnrollmentDto>>> UpdateGrade(int id, EnrollmentGradeDto dto) =>
        ToResult(await _service.UpdateGradeAsync(id, dto));

    /// <summary>Удалить студента с курса.</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<object>>> Delete(int id) =>
        ToResult(await _service.DeleteAsync(id));
}
