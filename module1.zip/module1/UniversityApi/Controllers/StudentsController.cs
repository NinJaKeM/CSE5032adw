using Microsoft.AspNetCore.Mvc;

namespace UniversityApi.Controllers;

[Route("api/students")]
public class StudentsController : ApiControllerBase
{
    private readonly IStudentService _service;

    public StudentsController(IStudentService service)
    {
        _service = service;
    }

    /// <summary>Получить всех студентов.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<IReadOnlyList<StudentDto>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ReturnResult<IReadOnlyList<StudentDto>>>> GetAll() =>
        ToResult(await _service.GetAllAsync());

    /// <summary>Получить студента по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<StudentDto>>> GetById(int id) =>
        ToResult(await _service.GetByIdAsync(id));

    /// <summary>Получить студента вместе с его курсами.</summary>
    [HttpGet("{id:int}/courses")]
    [ProducesResponseType(typeof(ReturnResult<StudentWithCoursesDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<StudentWithCoursesDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<StudentWithCoursesDto>>> GetWithCourses(int id) =>
        ToResult(await _service.GetWithCoursesAsync(id));

    /// <summary>Создать студента.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ReturnResult<StudentDto>>> Create(StudentCreateDto dto) =>
        ToCreated(await _service.CreateAsync(dto), nameof(GetById), s => new { id = s.Id });

    /// <summary>Изменить студента.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ReturnResult<StudentDto>), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ReturnResult<StudentDto>>> Update(int id, StudentUpdateDto dto) =>
        ToResult(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить студента (его записи на курсы удаляются каскадно).</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<object>>> Delete(int id) =>
        ToResult(await _service.DeleteAsync(id));
}
