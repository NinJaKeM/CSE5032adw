using Microsoft.AspNetCore.Mvc;

namespace UniversityApi.Controllers;

[Route("api/teachers")]
public class TeachersController : ApiControllerBase
{
    private readonly ITeacherService _service;

    public TeachersController(ITeacherService service)
    {
        _service = service;
    }

    /// <summary>Получить всех преподавателей.</summary>
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<IReadOnlyList<TeacherDto>>), StatusCodes.Status200OK)]
    public async Task<ActionResult<ReturnResult<IReadOnlyList<TeacherDto>>>> GetAll() =>
        ToResult(await _service.GetAllAsync());

    /// <summary>Получить преподавателя по Id.</summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status404NotFound)]
    public async Task<ActionResult<ReturnResult<TeacherDto>>> GetById(int id) =>
        ToResult(await _service.GetByIdAsync(id));

    /// <summary>Создать преподавателя.</summary>
    [HttpPost]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ReturnResult<TeacherDto>>> Create(TeacherCreateDto dto) =>
        ToCreated(await _service.CreateAsync(dto), nameof(GetById), t => new { id = t.Id });

    /// <summary>Изменить преподавателя.</summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ReturnResult<TeacherDto>), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ReturnResult<TeacherDto>>> Update(int id, TeacherUpdateDto dto) =>
        ToResult(await _service.UpdateAsync(id, dto));

    /// <summary>Удалить преподавателя (нельзя, если за ним закреплены курсы).</summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status404NotFound)]
    [ProducesResponseType(typeof(ReturnResult<object>), StatusCodes.Status409Conflict)]
    public async Task<ActionResult<ReturnResult<object>>> Delete(int id) =>
        ToResult(await _service.DeleteAsync(id));
}
