using Microsoft.AspNetCore.Mvc;

namespace UniversityApi.Controllers;

/// <summary>Базовый контроллер: HTTP-код ответа берётся из ReturnResult, добавляется TraceId.</summary>
[ApiController]
[Produces("application/json")]
public abstract class ApiControllerBase : ControllerBase
{
    protected ActionResult<ReturnResult<T>> ToResult<T>(ReturnResult<T> result)
    {
        result.TraceId = HttpContext.TraceIdentifier;
        return StatusCode(result.StatusCode, result);
    }

    protected ActionResult<ReturnResult<T>> ToCreated<T>(ReturnResult<T> result, string actionName, Func<T, object> routeValues)
    {
        result.TraceId = HttpContext.TraceIdentifier;
        if (!result.IsSuccess)
        {
            return StatusCode(result.StatusCode, result);
        }
        return CreatedAtAction(actionName, routeValues(result.Result!), result);
    }
}
