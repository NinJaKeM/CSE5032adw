﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE TABLE [Students] (
        [Id] int NOT NULL IDENTITY,
        [FirstName] nvarchar(100) NOT NULL,
        [LastName] nvarchar(100) NOT NULL,
        [Email] nvarchar(200) NOT NULL,
        [BirthDate] date NOT NULL,
        [CreatedAt] datetime2 NOT NULL DEFAULT (GETUTCDATE()),
        CONSTRAINT [PK_Students] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE TABLE [Teachers] (
        [Id] int NOT NULL IDENTITY,
        [FirstName] nvarchar(100) NOT NULL,
        [LastName] nvarchar(100) NOT NULL,
        [Email] nvarchar(200) NOT NULL,
        [Department] nvarchar(150) NOT NULL,
        CONSTRAINT [PK_Teachers] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE TABLE [Courses] (
        [Id] int NOT NULL IDENTITY,
        [Name] nvarchar(150) NOT NULL,
        [Description] nvarchar(1000) NOT NULL,
        [Credits] int NOT NULL,
        [TeacherId] int NOT NULL,
        [CreatedAt] datetime2 NOT NULL DEFAULT (GETUTCDATE()),
        CONSTRAINT [PK_Courses] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_Courses_Credits] CHECK ([Credits] BETWEEN 1 AND 10),
        CONSTRAINT [FK_Courses_Teachers_TeacherId] FOREIGN KEY ([TeacherId]) REFERENCES [Teachers] ([Id]) ON DELETE NO ACTION
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE TABLE [Enrollments] (
        [Id] int NOT NULL IDENTITY,
        [StudentId] int NOT NULL,
        [CourseId] int NOT NULL,
        [EnrollmentDate] datetime2 NOT NULL DEFAULT (GETUTCDATE()),
        [Grade] int NULL,
        CONSTRAINT [PK_Enrollments] PRIMARY KEY ([Id]),
        CONSTRAINT [CK_Enrollments_Grade] CHECK ([Grade] IS NULL OR [Grade] BETWEEN 0 AND 100),
        CONSTRAINT [FK_Enrollments_Courses_CourseId] FOREIGN KEY ([CourseId]) REFERENCES [Courses] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_Enrollments_Students_StudentId] FOREIGN KEY ([StudentId]) REFERENCES [Students] ([Id]) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'BirthDate', N'CreatedAt', N'Email', N'FirstName', N'LastName') AND [object_id] = OBJECT_ID(N'[Students]'))
        SET IDENTITY_INSERT [Students] ON;
    EXEC(N'INSERT INTO [Students] ([Id], [BirthDate], [CreatedAt], [Email], [FirstName], [LastName])
    VALUES (1, ''2004-03-15'', ''2026-09-01T09:00:00.0000000Z'', N''ivan.ivanov@student.kz'', N''Ivan'', N''Ivanov''),
    (2, ''2005-07-22'', ''2026-09-01T09:00:00.0000000Z'', N''anna.petrova@student.kz'', N''Anna'', N''Petrova''),
    (3, ''2004-11-02'', ''2026-09-01T09:00:00.0000000Z'', N''maxim.kim@student.kz'', N''Maxim'', N''Kim''),
    (4, ''2005-01-30'', ''2026-09-01T09:00:00.0000000Z'', N''aliya.seitkazy@student.kz'', N''Aliya'', N''Seitkazy'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'BirthDate', N'CreatedAt', N'Email', N'FirstName', N'LastName') AND [object_id] = OBJECT_ID(N'[Students]'))
        SET IDENTITY_INSERT [Students] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Department', N'Email', N'FirstName', N'LastName') AND [object_id] = OBJECT_ID(N'[Teachers]'))
        SET IDENTITY_INSERT [Teachers] ON;
    EXEC(N'INSERT INTO [Teachers] ([Id], [Department], [Email], [FirstName], [LastName])
    VALUES (1, N''Software Engineering'', N''aigerim.sadykova@university.kz'', N''Aigerim'', N''Sadykova''),
    (2, N''Computer Science'', N''daniyar.abenov@university.kz'', N''Daniyar'', N''Abenov''),
    (3, N''Mathematics'', N''marat.iskakov@university.kz'', N''Marat'', N''Iskakov'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Department', N'Email', N'FirstName', N'LastName') AND [object_id] = OBJECT_ID(N'[Teachers]'))
        SET IDENTITY_INSERT [Teachers] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'CreatedAt', N'Credits', N'Description', N'Name', N'TeacherId') AND [object_id] = OBJECT_ID(N'[Courses]'))
        SET IDENTITY_INSERT [Courses] ON;
    EXEC(N'INSERT INTO [Courses] ([Id], [CreatedAt], [Credits], [Description], [Name], [TeacherId])
    VALUES (1, ''2026-09-01T09:00:00.0000000Z'', 5, N''ASP.NET Core Web API, REST, EF Core'', N''Web Services Development'', 1),
    (2, ''2026-09-01T09:00:00.0000000Z'', 4, N''Relational databases and SQL'', N''Databases'', 2),
    (3, ''2026-09-01T09:00:00.0000000Z'', 6, N''Sorting, graphs, complexity'', N''Algorithms and Data Structures'', 2),
    (4, ''2026-09-01T09:00:00.0000000Z'', 3, N''Matrices, vector spaces'', N''Linear Algebra'', 3)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'CreatedAt', N'Credits', N'Description', N'Name', N'TeacherId') AND [object_id] = OBJECT_ID(N'[Courses]'))
        SET IDENTITY_INSERT [Courses] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'CourseId', N'EnrollmentDate', N'Grade', N'StudentId') AND [object_id] = OBJECT_ID(N'[Enrollments]'))
        SET IDENTITY_INSERT [Enrollments] ON;
    EXEC(N'INSERT INTO [Enrollments] ([Id], [CourseId], [EnrollmentDate], [Grade], [StudentId])
    VALUES (1, 1, ''2026-09-01T09:00:00.0000000Z'', 90, 1),
    (2, 2, ''2026-09-01T09:00:00.0000000Z'', NULL, 1),
    (3, 1, ''2026-09-01T09:00:00.0000000Z'', 85, 2),
    (4, 3, ''2026-09-01T09:00:00.0000000Z'', NULL, 3),
    (5, 4, ''2026-09-01T09:00:00.0000000Z'', 78, 4)');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'CourseId', N'EnrollmentDate', N'Grade', N'StudentId') AND [object_id] = OBJECT_ID(N'[Enrollments]'))
        SET IDENTITY_INSERT [Enrollments] OFF;
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Courses_TeacherId] ON [Courses] ([TeacherId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Enrollments_CourseId] ON [Enrollments] ([CourseId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Enrollments_StudentId_CourseId] ON [Enrollments] ([StudentId], [CourseId]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Students_Email] ON [Students] ([Email]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    CREATE UNIQUE INDEX [IX_Teachers_Email] ON [Teachers] ([Email]);
END;
GO

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261004140507_InitialCreate'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20261004140507_InitialCreate', N'8.0.0');
END;
GO

COMMIT;
GO

