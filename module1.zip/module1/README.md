# University Course Management API

Модульное задание 1 (Модули 1–4), CSE5032 «Разработка веб-сервисов».

REST Web API на ASP.NET Core 8 для управления университетскими курсами: студенты, преподаватели, учебные курсы и записи студентов на курсы. Данные хранятся в MS SQL Server (LocalDB) через Entity Framework Core.

## Технологии

ASP.NET Core Web API (.NET 8) · Entity Framework Core 8 (SQL Server) · AutoMapper · Swagger / OpenAPI (Swashbuckle) · ILogger

## Архитектура

```
Client (Swagger / Postman / Web / Mobile)
  ↓ HTTP + JSON
Controller            [ApiController], атрибутная маршрутизация, только приём запроса и выдача ответа
  ↓ DTO
Service               бизнес-правила, логирование, AutoMapper (DTO ↔ Entity), ReturnResult
  ↓ Entity
Repository            запросы к данным через ApplicationDbContext
  ↓
Entity Framework Core ORM, миграции Code First
  ↓
Database              MS SQL Server (LocalDB), база UniversityDb
```

Сквозные компоненты: `ExceptionHandlingMiddleware` (ошибки 500), `InvalidModelStateResponseFactory` (ошибки валидации 400), `ReturnResult<T>` (единый формат ответа).

## Структура проекта

```
UniversityApi
├── Controllers        StudentsController, TeachersController, CoursesController, EnrollmentsController,
│                      DiagnosticsController, ApiControllerBase
├── Models             Student, Teacher, Course, Enrollment
├── Dtos               Students / Teachers / Courses / Enrollments (Create, Update, Dto, Filter)
├── Data               ApplicationDbContext, SeedData, Configurations (Fluent API)
├── Repositories       Interfaces / Implementations
├── Services           Interfaces / Implementations (бизнес-логика)
├── Mapping            MappingProfile (AutoMapper)
├── Middleware         ExceptionHandlingMiddleware
├── Common             ReturnResult<T>, ErrorCodes
├── Migrations         InitialCreate (схема + тестовые данные)
├── Program.cs
└── appsettings.json
Database/UniversityDb.sql   SQL-скрипт базы с тестовыми данными
screenshots/                скриншоты проверки через Swagger и лог приложения
logs/app-log-sample.txt     пример лога
```

## Модель данных

| Сущность | Поля | Связи |
|---|---|---|
| Student | Id, FirstName, LastName, Email, BirthDate, CreatedAt | 1 → N Enrollment |
| Teacher | Id, FirstName, LastName, Email, Department | 1 → N Course |
| Course | Id, Name, Description, Credits, TeacherId, CreatedAt | N → 1 Teacher, 1 → N Enrollment |
| Enrollment | Id, StudentId, CourseId, EnrollmentDate, Grade | N → 1 Student, N → 1 Course |

Student ↔ Course — многие-ко-многим через Enrollment.

### Конфигурация модели (два способа)

- **Data Annotations** — `Student`, `Teacher`: `[Required]`, `[MaxLength]`.
- **Fluent API** — `Data/Configurations/*Configuration.cs`: первичные ключи, длины строк `Course`, внешние ключи и поведение удаления (`Course → Teacher`: Restrict, `Enrollment → Student/Course`: Cascade), уникальные индексы (Email студента и преподавателя, пара `StudentId + CourseId`), check-ограничения (`Credits 1..10`, `Grade 0..100`), значения по умолчанию `GETUTCDATE()`.
- **Conventions** — свойство `Id` автоматически становится ключом, навигационные свойства задают связи.

## Endpoints

| Метод | URL | Описание | Коды |
|---|---|---|---|
| GET | `/api/students` | Все студенты | 200 |
| GET | `/api/students/{id}` | Студент по Id | 200, 404 |
| GET | `/api/students/{id}/courses` | Студент вместе с его курсами | 200, 404 |
| POST | `/api/students` | Создать студента | 201, 400, 409 |
| PUT | `/api/students/{id}` | Изменить студента | 200, 400, 404, 409 |
| DELETE | `/api/students/{id}` | Удалить студента (записи удаляются каскадно) | 200, 404 |
| GET | `/api/teachers` | Все преподаватели | 200 |
| GET | `/api/teachers/{id}` | Преподаватель по Id | 200, 404 |
| POST | `/api/teachers` | Создать преподавателя | 201, 400, 409 |
| PUT | `/api/teachers/{id}` | Изменить преподавателя | 200, 400, 404, 409 |
| DELETE | `/api/teachers/{id}` | Удалить преподавателя (нельзя, если есть курсы) | 200, 404, 409 |
| GET | `/api/courses?TeacherId=&MinCredits=&MaxCredits=&Search=` | Курсы с фильтрацией | 200, 400 |
| GET | `/api/courses/{id}` | Курс по Id | 200, 404 |
| POST | `/api/courses` | Создать курс и привязать преподавателя | 201, 400, 404 |
| PUT | `/api/courses/{id}` | Изменить курс | 200, 400, 404 |
| DELETE | `/api/courses/{id}` | Удалить курс | 200, 404 |
| GET | `/api/enrollments` | Список записей | 200 |
| GET | `/api/enrollments/{id}` | Запись по Id | 200, 404 |
| POST | `/api/enrollments` | Записать студента на курс | 201, 400, 404, 409 |
| PUT | `/api/enrollments/{id}/grade` | Изменить оценку | 200, 400, 404 |
| DELETE | `/api/enrollments/{id}` | Удалить студента с курса | 200, 404 |
| GET | `/api/diagnostics/error` | Проверка обработки ошибок (только Development) | 500 |

## Единый формат ответа

```json
{
  "statusCode": 404,
  "isSuccess": false,
  "result": null,
  "errorCode": "STUDENT_NOT_FOUND",
  "errorMessage": "Student with id 999 not found",
  "traceId": "0HNP2436MJ7VO:0000000F"
}
```

Для ошибок валидации дополнительно возвращается поле `errors` — список ошибок по каждому полю.

## Бизнес-правила

| № | Правило | Ответ |
|---|---|---|
| 1 | Нельзя записать студента на несуществующий курс | 404 `COURSE_NOT_FOUND` |
| 2 | Нельзя записать несуществующего студента | 404 `STUDENT_NOT_FOUND` |
| 3 | Студент не может быть дважды записан на один курс (проверка в сервисе + уникальный индекс) | 409 `STUDENT_ALREADY_ENROLLED` |
| 4 | Курс не может ссылаться на несуществующего преподавателя | 404 `TEACHER_NOT_FOUND` |
| 5 | Несуществующий объект не возвращается как успешный результат | 404 `*_NOT_FOUND` |
| — | Email студента / преподавателя уникален | 409 `*_EMAIL_EXISTS` |
| — | Нельзя удалить преподавателя, за которым закреплены курсы | 409 `TEACHER_HAS_COURSES` |

## Dependency Injection и lifetime

| Сервис | Lifetime | Почему |
|---|---|---|
| `ApplicationDbContext` | Scoped (`AddDbContext`) | DbContext не потокобезопасен и отслеживает изменения в рамках одной единицы работы — одного HTTP-запроса |
| `I*Repository` | Scoped | Зависят от DbContext; Singleton удерживал бы один контекст на всё приложение |
| `I*Service` | Scoped | Зависят от репозиториев (Scoped); живут столько же, сколько запрос |
| AutoMapper (`IMapper`) | конфигурация создаётся один раз | Профили маппинга неизменяемы, пересоздавать их на каждый запрос не нужно |

Репозитории и сервисы нигде не создаются через `new` — только через конструктор.

## Логирование

`ILogger<T>` в сервисах и middleware:

- **Information** — создание, изменение и удаление объектов;
- **Warning** — попытка получить несуществующий объект, конфликты, ошибки валидации;
- **Error** — непредвиденные исключения (полный stack trace только в логе, клиент получает `INTERNAL_SERVER_ERROR` без технических деталей).

Пример — `logs/app-log-sample.txt`, скриншот — `screenshots/24_logs.png`.

## Запуск

1. Visual Studio 2022 с нагрузкой «Data storage and processing» (SQL Server LocalDB).
2. Открыть `UniversityApi.slnx`.
3. Создать базу (Package Manager Console): `Update-Database` — либо выполнить `Database/UniversityDb.sql`.
4. F5 → Swagger: https://localhost:7011/swagger.

Строка подключения — `appsettings.json`, `ConnectionStrings:DefaultConnection` (`Server=(localdb)\mssqllocaldb;Database=UniversityDb`).

## Тестовые данные

3 преподавателя, 4 студента, 4 курса, 5 записей на курсы — добавляются миграцией `InitialCreate` (`Data/SeedData.cs`).

## Скриншоты проверки (папка `screenshots`)

| Файл | Сценарий |
|---|---|
| 00 | Все endpoints в Swagger |
| 01–04 | Список студентов, создание, получение по Id, изменение |
| 05–06 | Создание преподавателя, создание курса с привязкой преподавателя |
| 07–10 | Запись на курс, повторная запись (409), вторая запись, студент с курсами |
| 11–12 | Фильтрация курсов |
| 13–16 | Изменение оценки, список записей, удаление с курса, удаление преподавателя с курсами (409) |
| 17 | Несуществующий объект (404) |
| 18–19 | Ошибки валидации (400) |
| 20–22 | Бизнес-правила 4, 2, 1 (404) |
| 23 | Непредвиденная ошибка (500) |
| 24 | Лог приложения |
